﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Windows.Forms;
using System.Data;

namespace QuanLyGiuongBenhVien.Models
{
    class LoginMod
    {
        //Khai báo biến
        protected string user { get; set; }
        protected string pass { get; set; }
        
        //biến status để kiểm tra trạng thái tài khoản
        protected bool status { get; set; }
        public LoginMod(string _user, string _pass)
        {
            this.user = _user;
            this.pass = _pass;
        }
        
        //Check đăng nhập 
        public string ADMIN_Select_TK()
        {
            string str = "";
            string[] para = new string[2] { "@taikhoan", "@matkhau" };
            object[] value = new object[2] { user, pass };
            str = Models.Connection.ExcuteScalar("ADMIN_Select_TK", CommandType.StoredProcedure, para, value);
            //str = Models.Connection.ExcuteScalar("NHANVIEN_Select_TK", CommandType.StoredProcedure, para, value);
            return str;
            
        }
        
        

    }
}
