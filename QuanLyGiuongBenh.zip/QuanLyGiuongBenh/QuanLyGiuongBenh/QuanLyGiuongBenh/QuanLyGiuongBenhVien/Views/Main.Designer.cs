﻿namespace QuanLyGiuongBenhVien
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.ribbon = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.skinRibbonGalleryBarItem1 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.btnLogin = new DevExpress.XtraBars.BarButtonItem();
            this.btnDoimatkhau = new DevExpress.XtraBars.BarButtonItem();
            this.btnLogout = new DevExpress.XtraBars.BarButtonItem();
            this.skinRibbonGalleryBarItem2 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem8 = new DevExpress.XtraBars.BarButtonItem();
            this.btnDocGia = new DevExpress.XtraBars.BarButtonItem();
            this.btnSach = new DevExpress.XtraBars.BarButtonItem();
            this.btnLoaiSach = new DevExpress.XtraBars.BarButtonItem();
            this.btnNhaXuatBan = new DevExpress.XtraBars.BarButtonItem();
            this.btnNhanVien = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem9 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem10 = new DevExpress.XtraBars.BarButtonItem();
            this.skinRibbonGalleryBarItem3 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.barButtonItem12 = new DevExpress.XtraBars.BarButtonItem();
            this.btnExit = new DevExpress.XtraBars.BarButtonItem();
            this.btn_BacSy = new DevExpress.XtraBars.BarButtonItem();
            this.btn_BenhNhan = new DevExpress.XtraBars.BarButtonItem();
            this.btn_GiuongBenh = new DevExpress.XtraBars.BarButtonItem();
            this.btn_PhongBenh = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.btn_SapXepBN = new DevExpress.XtraBars.BarButtonItem();
            this.btn_PhanCong = new DevExpress.XtraBars.BarButtonItem();
            this.btn_PC = new DevExpress.XtraBars.BarButtonItem();
            this.btn_HoaDon = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup8 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rbQLDanhMuc = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup7 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup9 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rbMTSach = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.barButtonItem11 = new DevExpress.XtraBars.BarButtonItem();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.Tab_SapXepBenhNhan = new DevExpress.XtraTab.XtraTabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.btn_XoaSX = new DevExpress.XtraEditors.SimpleButton();
            this.btn_SuaSX = new DevExpress.XtraEditors.SimpleButton();
            this.btn_ThemSX = new DevExpress.XtraEditors.SimpleButton();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.btn_HuySX = new DevExpress.XtraEditors.SimpleButton();
            this.btn_LuuSX = new DevExpress.XtraEditors.SimpleButton();
            this.label36 = new System.Windows.Forms.Label();
            this.txt_MGBSapXep = new DevExpress.XtraEditors.TextEdit();
            this.txt_MSBNSapXep = new DevExpress.XtraEditors.TextEdit();
            this.btn_LoadSX = new DevExpress.XtraEditors.SimpleButton();
            this.date_TimeNV = new DevExpress.XtraEditors.DateEdit();
            this.date_TimeXV = new DevExpress.XtraEditors.DateEdit();
            this.label38 = new System.Windows.Forms.Label();
            this.grd_SXBN = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridViewSXBN = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn29 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Tab_PhanCong = new DevExpress.XtraTab.XtraTabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.txt_DiUngThuoc = new DevExpress.XtraEditors.TextEdit();
            this.btn_HuyPC = new DevExpress.XtraEditors.SimpleButton();
            this.btn_LuuPC = new DevExpress.XtraEditors.SimpleButton();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txt_NhomMau = new DevExpress.XtraEditors.TextEdit();
            this.txt_TinhTrangBN = new DevExpress.XtraEditors.TextEdit();
            this.txt_MaBacSyPC = new DevExpress.XtraEditors.TextEdit();
            this.txt_MaBenhNhanPC = new DevExpress.XtraEditors.TextEdit();
            this.btn_LoadPC = new DevExpress.XtraEditors.SimpleButton();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.txt_TienSuBA = new DevExpress.XtraEditors.TextEdit();
            this.date_TimePC = new DevExpress.XtraEditors.DateEdit();
            this.grd_PhanCong = new DevExpress.XtraGrid.GridControl();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridViewPhanCong = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btn_XoaPC = new DevExpress.XtraEditors.SimpleButton();
            this.btn_SuaPC = new DevExpress.XtraEditors.SimpleButton();
            this.btn_ThemPC = new DevExpress.XtraEditors.SimpleButton();
            this.Tab_PhongBenh = new DevExpress.XtraTab.XtraTabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.checkE_PhongBenh = new DevExpress.XtraEditors.CheckEdit();
            this.txt_MaPB = new DevExpress.XtraEditors.TextEdit();
            this.txt_TenPhongBenh = new DevExpress.XtraEditors.TextEdit();
            this.txt_SoGiuongBenh = new DevExpress.XtraEditors.TextEdit();
            this.btn_HuyPB = new DevExpress.XtraEditors.SimpleButton();
            this.btn_LuuPB = new DevExpress.XtraEditors.SimpleButton();
            this.label26 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_LoaiPhong = new DevExpress.XtraEditors.TextEdit();
            this.btn_LoadPB = new DevExpress.XtraEditors.SimpleButton();
            this.grd_PhongBenh = new DevExpress.XtraGrid.GridControl();
            this.gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridViewPhongBenh = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btn_XoaPB = new DevExpress.XtraEditors.SimpleButton();
            this.btn_SuaPB = new DevExpress.XtraEditors.SimpleButton();
            this.btn_ThemPB = new DevExpress.XtraEditors.SimpleButton();
            this.Tab_GiuongBenh = new DevExpress.XtraTab.XtraTabPage();
            this.grd_GiuongBenh = new DevExpress.XtraGrid.GridControl();
            this.gridView5 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridViewGiuongBenh = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.checkE_NguoiNam = new DevExpress.XtraEditors.CheckEdit();
            this.txt_MaGiuongBenh = new DevExpress.XtraEditors.TextEdit();
            this.txt_LoaiGiuongBenh = new DevExpress.XtraEditors.TextEdit();
            this.btn_HuyGB = new DevExpress.XtraEditors.SimpleButton();
            this.btn_LuuGB = new DevExpress.XtraEditors.SimpleButton();
            this.label22 = new System.Windows.Forms.Label();
            this.btn_LoadGB = new DevExpress.XtraEditors.SimpleButton();
            this.txt_MaPhong = new DevExpress.XtraEditors.TextEdit();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btn_XoaGB = new DevExpress.XtraEditors.SimpleButton();
            this.btn_SuaGB = new DevExpress.XtraEditors.SimpleButton();
            this.btn_ThemGB = new DevExpress.XtraEditors.SimpleButton();
            this.Tab_BenhNhan = new DevExpress.XtraTab.XtraTabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_MaBN = new DevExpress.XtraEditors.TextEdit();
            this.txt_EmailBN = new DevExpress.XtraEditors.TextEdit();
            this.txt_NgheNghiepBN = new DevExpress.XtraEditors.TextEdit();
            this.txt_SdtBN = new DevExpress.XtraEditors.TextEdit();
            this.txt_DiaChiBN = new DevExpress.XtraEditors.TextEdit();
            this.txt_CMNDBN = new DevExpress.XtraEditors.TextEdit();
            this.txt_HoTenBN = new DevExpress.XtraEditors.TextEdit();
            this.rdb_NamBN = new System.Windows.Forms.RadioButton();
            this.rdb_NuBN = new System.Windows.Forms.RadioButton();
            this.det_NgaySinhBN = new DevExpress.XtraEditors.DateEdit();
            this.btn_HuyBN = new DevExpress.XtraEditors.SimpleButton();
            this.btn_LuuBN = new DevExpress.XtraEditors.SimpleButton();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_NoiSinhBN = new DevExpress.XtraEditors.TextEdit();
            this.btn_LoadBN = new DevExpress.XtraEditors.SimpleButton();
            this.grd_BenhNhan = new DevExpress.XtraGrid.GridControl();
            this.gridView6 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridViewBenhNhan = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.MaBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.HoTenBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GioiTinhBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.DiaChiBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.NgaySinhBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.NoiSinhBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CMNDBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.sdtBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.NgheNghiepBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.EmailBN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rdb_MaBN = new System.Windows.Forms.RadioButton();
            this.rdb_TenBN = new System.Windows.Forms.RadioButton();
            this.txt_SearchMaBN = new DevExpress.XtraEditors.TextEdit();
            this.txt_SearchTenBN = new DevExpress.XtraEditors.TextEdit();
            this.btn_HuySearchBN = new DevExpress.XtraEditors.SimpleButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btn_XoaBN = new DevExpress.XtraEditors.SimpleButton();
            this.btn_SuaBN = new DevExpress.XtraEditors.SimpleButton();
            this.btn_ThemBN = new DevExpress.XtraEditors.SimpleButton();
            this.Tab_BacSy = new DevExpress.XtraTab.XtraTabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_MaBacSy = new DevExpress.XtraEditors.TextEdit();
            this.txt_Email = new DevExpress.XtraEditors.TextEdit();
            this.txt_TrinhDoCM = new DevExpress.XtraEditors.TextEdit();
            this.txt_SoDienThoai = new DevExpress.XtraEditors.TextEdit();
            this.txt_DiaChi = new DevExpress.XtraEditors.TextEdit();
            this.txt_CMND = new DevExpress.XtraEditors.TextEdit();
            this.txt_HoTen = new DevExpress.XtraEditors.TextEdit();
            this.txt_MaKhoa = new DevExpress.XtraEditors.TextEdit();
            this.rdb_Nam = new System.Windows.Forms.RadioButton();
            this.rdb_Nu = new System.Windows.Forms.RadioButton();
            this.det_NgaySinh = new DevExpress.XtraEditors.DateEdit();
            this.btn_HuyBS = new DevExpress.XtraEditors.SimpleButton();
            this.btn_LuuBS = new DevExpress.XtraEditors.SimpleButton();
            this.label21 = new System.Windows.Forms.Label();
            this.btn_LoadBS = new DevExpress.XtraEditors.SimpleButton();
            this.grd_BacSy = new DevExpress.XtraGrid.GridControl();
            this.gridView7 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridViewBacSy = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.MaBS = new DevExpress.XtraGrid.Columns.GridColumn();
            this.MaKhoa = new DevExpress.XtraGrid.Columns.GridColumn();
            this.HoTen = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GioiTinh = new DevExpress.XtraGrid.Columns.GridColumn();
            this.NgaySinh = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CMND = new DevExpress.XtraGrid.Columns.GridColumn();
            this.DiaChi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.SoDienThoai = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Email = new DevExpress.XtraGrid.Columns.GridColumn();
            this.TrinhDoChuyenMon = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdb_MaBS = new System.Windows.Forms.RadioButton();
            this.rdb_TenBS = new System.Windows.Forms.RadioButton();
            this.txt_SearchMaBS = new DevExpress.XtraEditors.TextEdit();
            this.txt_SearchTenBS = new DevExpress.XtraEditors.TextEdit();
            this.btn_HuySearchBS = new DevExpress.XtraEditors.SimpleButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btn_XoaBS = new DevExpress.XtraEditors.SimpleButton();
            this.btn_SuaBS = new DevExpress.XtraEditors.SimpleButton();
            this.btn_ThemBS = new DevExpress.XtraEditors.SimpleButton();
            this.Tab_GioiThieu = new DevExpress.XtraTab.XtraTabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Tab_Main = new DevExpress.XtraTab.XtraTabControl();
            ((System.ComponentModel.ISupportInitialize)(this.ribbon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.Tab_SapXepBenhNhan.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MGBSapXep.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MSBNSapXep.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimeNV.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimeNV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimeXV.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimeXV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_SXBN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSXBN)).BeginInit();
            this.Tab_PhanCong.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DiUngThuoc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NhomMau.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TinhTrangBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaBacSyPC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaBenhNhanPC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TienSuBA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimePC.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimePC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_PhanCong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPhanCong)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.Tab_PhongBenh.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkE_PhongBenh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaPB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TenPhongBenh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SoGiuongBenh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_LoaiPhong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_PhongBenh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPhongBenh)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.Tab_GiuongBenh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd_GiuongBenh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGiuongBenh)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkE_NguoiNam.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaGiuongBenh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_LoaiGiuongBenh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaPhong.Properties)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.Tab_BenhNhan.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_EmailBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NgheNghiepBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SdtBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DiaChiBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_CMNDBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_HoTenBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.det_NgaySinhBN.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.det_NgaySinhBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NoiSinhBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_BenhNhan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewBenhNhan)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SearchMaBN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SearchTenBN.Properties)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.Tab_BacSy.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaBacSy.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Email.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TrinhDoCM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SoDienThoai.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DiaChi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_CMND.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_HoTen.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaKhoa.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.det_NgaySinh.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.det_NgaySinh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_BacSy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewBacSy)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SearchMaBS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SearchTenBS.Properties)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.Tab_GioiThieu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab_Main)).BeginInit();
            this.Tab_Main.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbon
            // 
            this.ribbon.ExpandCollapseItem.Id = 0;
            this.ribbon.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbon.ExpandCollapseItem,
            this.barButtonItem1,
            this.barButtonGroup1,
            this.skinRibbonGalleryBarItem1,
            this.barButtonItem3,
            this.btnLogin,
            this.btnDoimatkhau,
            this.btnLogout,
            this.skinRibbonGalleryBarItem2,
            this.barButtonItem4,
            this.barButtonItem5,
            this.barButtonItem6,
            this.barButtonItem7,
            this.barButtonItem8,
            this.btnDocGia,
            this.btnSach,
            this.btnLoaiSach,
            this.btnNhaXuatBan,
            this.btnNhanVien,
            this.barButtonItem9,
            this.barButtonItem10,
            this.skinRibbonGalleryBarItem3,
            this.barButtonItem12,
            this.btnExit,
            this.btn_BacSy,
            this.btn_BenhNhan,
            this.btn_GiuongBenh,
            this.btn_PhongBenh,
            this.barButtonItem2,
            this.btn_SapXepBN,
            this.btn_PhanCong,
            this.btn_PC,
            this.btn_HoaDon,
            this.barStaticItem1});
            this.ribbon.Location = new System.Drawing.Point(0, 0);
            this.ribbon.MaxItemId = 42;
            this.ribbon.Name = "ribbon";
            this.ribbon.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage2,
            this.rbQLDanhMuc,
            this.rbMTSach});
            this.ribbon.Size = new System.Drawing.Size(1187, 143);
            this.ribbon.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above;
            this.ribbon.Click += new System.EventHandler(this.ribbon_Click);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.ActAsDropDown = true;
            this.barButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 3;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Caption = "barButtonGroup1";
            this.barButtonGroup1.Id = 4;
            this.barButtonGroup1.Name = "barButtonGroup1";
            // 
            // skinRibbonGalleryBarItem1
            // 
            this.skinRibbonGalleryBarItem1.Caption = "skinRibbonGalleryBarItem1";
            this.skinRibbonGalleryBarItem1.Id = 8;
            this.skinRibbonGalleryBarItem1.Name = "skinRibbonGalleryBarItem1";
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "barButtonItem3";
            this.barButtonItem3.Id = 10;
            this.barButtonItem3.Name = "barButtonItem3";
            // 
            // btnLogin
            // 
            this.btnLogin.Caption = "Đăng nhập";
            this.btnLogin.Id = 11;
            this.btnLogin.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnLogin.ImageOptions.Image")));
            this.btnLogin.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B));
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnLogin.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnLogin_ItemClick);
            // 
            // btnDoimatkhau
            // 
            this.btnDoimatkhau.Caption = "Đổi mật khẩu";
            this.btnDoimatkhau.Id = 12;
            this.btnDoimatkhau.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnDoimatkhau.ImageOptions.Image")));
            this.btnDoimatkhau.Name = "btnDoimatkhau";
            this.btnDoimatkhau.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnDoimatkhau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDoimatkhau_ItemClick);
            // 
            // btnLogout
            // 
            this.btnLogout.Caption = "Đăng xuất";
            this.btnLogout.Id = 13;
            this.btnLogout.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnLogout.ImageOptions.Image")));
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnLogout.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnLogout_ItemClick);
            // 
            // skinRibbonGalleryBarItem2
            // 
            this.skinRibbonGalleryBarItem2.Caption = "skinRibbonGalleryBarItem2";
            this.skinRibbonGalleryBarItem2.Id = 14;
            this.skinRibbonGalleryBarItem2.Name = "skinRibbonGalleryBarItem2";
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Id = 15;
            this.barButtonItem4.Name = "barButtonItem4";
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "barButtonItem5";
            this.barButtonItem5.Id = 16;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "barButtonItem6";
            this.barButtonItem6.Id = 17;
            this.barButtonItem6.Name = "barButtonItem6";
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "barButtonItem7";
            this.barButtonItem7.Id = 18;
            this.barButtonItem7.Name = "barButtonItem7";
            // 
            // barButtonItem8
            // 
            this.barButtonItem8.Caption = "barButtonItem8";
            this.barButtonItem8.Id = 19;
            this.barButtonItem8.Name = "barButtonItem8";
            // 
            // btnDocGia
            // 
            this.btnDocGia.Caption = "Độc Giả";
            this.btnDocGia.Id = 20;
            this.btnDocGia.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnDocGia.ImageOptions.Image")));
            this.btnDocGia.Name = "btnDocGia";
            this.btnDocGia.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnSach
            // 
            this.btnSach.Caption = "Sách";
            this.btnSach.Id = 21;
            this.btnSach.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSach.ImageOptions.Image")));
            this.btnSach.Name = "btnSach";
            this.btnSach.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnLoaiSach
            // 
            this.btnLoaiSach.Caption = "Loại Sách";
            this.btnLoaiSach.Id = 22;
            this.btnLoaiSach.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnLoaiSach.ImageOptions.Image")));
            this.btnLoaiSach.Name = "btnLoaiSach";
            this.btnLoaiSach.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnNhaXuatBan
            // 
            this.btnNhaXuatBan.Caption = "Nhà Xuất Bản";
            this.btnNhaXuatBan.Id = 23;
            this.btnNhaXuatBan.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnNhaXuatBan.ImageOptions.Image")));
            this.btnNhaXuatBan.Name = "btnNhaXuatBan";
            this.btnNhaXuatBan.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnNhanVien
            // 
            this.btnNhanVien.Caption = "Nhân Viên";
            this.btnNhanVien.Id = 24;
            this.btnNhanVien.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnNhanVien.ImageOptions.Image")));
            this.btnNhanVien.Name = "btnNhanVien";
            this.btnNhanVien.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // barButtonItem9
            // 
            this.barButtonItem9.Caption = "barButtonItem9";
            this.barButtonItem9.Id = 25;
            this.barButtonItem9.Name = "barButtonItem9";
            // 
            // barButtonItem10
            // 
            this.barButtonItem10.Caption = "barButtonItem10";
            this.barButtonItem10.Id = 26;
            this.barButtonItem10.Name = "barButtonItem10";
            // 
            // skinRibbonGalleryBarItem3
            // 
            this.skinRibbonGalleryBarItem3.Caption = "skinRibbonGalleryBarItem3";
            this.skinRibbonGalleryBarItem3.Id = 27;
            this.skinRibbonGalleryBarItem3.Name = "skinRibbonGalleryBarItem3";
            // 
            // barButtonItem12
            // 
            this.barButtonItem12.Caption = "barButtonItem12";
            this.barButtonItem12.Id = 29;
            this.barButtonItem12.Name = "barButtonItem12";
            // 
            // btnExit
            // 
            this.btnExit.Caption = "Thoát Chương Trình";
            this.btnExit.Id = 31;
            this.btnExit.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.ImageOptions.Image")));
            this.btnExit.Name = "btnExit";
            this.btnExit.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnExit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnExit_ItemClick);
            // 
            // btn_BacSy
            // 
            this.btn_BacSy.Caption = "Thông Tin Bác Sỹ";
            this.btn_BacSy.Id = 32;
            this.btn_BacSy.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_BacSy.ImageOptions.Image")));
            this.btn_BacSy.Name = "btn_BacSy";
            this.btn_BacSy.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btn_BacSy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_BacSy_ItemClick);
            // 
            // btn_BenhNhan
            // 
            this.btn_BenhNhan.Caption = "Thông Tin Bệnh Nhân";
            this.btn_BenhNhan.Id = 33;
            this.btn_BenhNhan.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_BenhNhan.ImageOptions.Image")));
            this.btn_BenhNhan.Name = "btn_BenhNhan";
            this.btn_BenhNhan.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btn_BenhNhan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_BenhNhan_ItemClick);
            // 
            // btn_GiuongBenh
            // 
            this.btn_GiuongBenh.Caption = "Thông Tin Giường Bệnh";
            this.btn_GiuongBenh.Id = 34;
            this.btn_GiuongBenh.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_GiuongBenh.ImageOptions.Image")));
            this.btn_GiuongBenh.Name = "btn_GiuongBenh";
            this.btn_GiuongBenh.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btn_GiuongBenh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_GiuongBenh_ItemClick);
            // 
            // btn_PhongBenh
            // 
            this.btn_PhongBenh.Caption = "Thông Tin Phòng Bệnh";
            this.btn_PhongBenh.Id = 35;
            this.btn_PhongBenh.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_PhongBenh.ImageOptions.Image")));
            this.btn_PhongBenh.Name = "btn_PhongBenh";
            this.btn_PhongBenh.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btn_PhongBenh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_PhongBenh_ItemClick);
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Phân Công";
            this.barButtonItem2.Id = 36;
            this.barButtonItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem2.ImageOptions.Image")));
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btn_SapXepBN
            // 
            this.btn_SapXepBN.Caption = "Sắp Xếp Bệnh Nhân";
            this.btn_SapXepBN.Id = 37;
            this.btn_SapXepBN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_SapXepBN.ImageOptions.Image")));
            this.btn_SapXepBN.Name = "btn_SapXepBN";
            this.btn_SapXepBN.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btn_SapXepBN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_SapXepBN_ItemClick);
            // 
            // btn_PhanCong
            // 
            this.btn_PhanCong.Caption = "Phân Công";
            this.btn_PhanCong.Id = 38;
            this.btn_PhanCong.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_PhanCong.ImageOptions.Image")));
            this.btn_PhanCong.Name = "btn_PhanCong";
            this.btn_PhanCong.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btn_PhanCong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem13_ItemClick);
            // 
            // btn_PC
            // 
            this.btn_PC.Caption = "Phân Công Điều Trị";
            this.btn_PC.Id = 39;
            this.btn_PC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_PC.ImageOptions.Image")));
            this.btn_PC.Name = "btn_PC";
            this.btn_PC.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btn_PC.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_PC_ItemClick);
            // 
            // btn_HoaDon
            // 
            this.btn_HoaDon.Caption = "Hóa Đơn";
            this.btn_HoaDon.Id = 40;
            this.btn_HoaDon.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HoaDon.ImageOptions.Image")));
            this.btn_HoaDon.Name = "btn_HoaDon";
            this.btn_HoaDon.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            //this.btn_HoaDon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_HoaDon_ItemClick);
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = "barStaticItem1";
            this.barStaticItem1.Id = 41;
            this.barStaticItem1.Name = "barStaticItem1";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2,
            this.ribbonPageGroup8});
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Hệ Thống";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.btnLogin);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnDoimatkhau);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnLogout);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnExit);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Bảo mật";
            // 
            // ribbonPageGroup8
            // 
            this.ribbonPageGroup8.ItemLinks.Add(this.skinRibbonGalleryBarItem1);
            this.ribbonPageGroup8.Name = "ribbonPageGroup8";
            this.ribbonPageGroup8.Text = "Giao diện";
            // 
            // rbQLDanhMuc
            // 
            this.rbQLDanhMuc.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3,
            this.ribbonPageGroup1,
            this.ribbonPageGroup7,
            this.ribbonPageGroup9});
            this.rbQLDanhMuc.Name = "rbQLDanhMuc";
            this.rbQLDanhMuc.Text = "Quản Lý Danh Mục";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.btn_BacSy);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.btn_BenhNhan);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            // 
            // ribbonPageGroup7
            // 
            this.ribbonPageGroup7.ItemLinks.Add(this.btn_GiuongBenh);
            this.ribbonPageGroup7.Name = "ribbonPageGroup7";
            // 
            // ribbonPageGroup9
            // 
            this.ribbonPageGroup9.ItemLinks.Add(this.btn_PhongBenh);
            this.ribbonPageGroup9.Name = "ribbonPageGroup9";
            // 
            // rbMTSach
            // 
            this.rbMTSach.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup4,
            this.ribbonPageGroup6});
            this.rbMTSach.Name = "rbMTSach";
            this.rbMTSach.Text = "Điều Trị/Sắp Xếp Bệnh Nhân Nội Trú";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.btn_PC);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.ItemLinks.Add(this.btn_SapXepBN);
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            // 
            // barButtonItem11
            // 
            this.barButtonItem11.Caption = "Phân Công";
            this.barButtonItem11.Id = 38;
            this.barButtonItem11.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem11.ImageOptions.Image")));
            this.barButtonItem11.Name = "barButtonItem11";
            this.barButtonItem11.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // gridView1
            // 
            this.gridView1.Name = "gridView1";
            // 
            // Tab_SapXepBenhNhan
            // 
            this.Tab_SapXepBenhNhan.Controls.Add(this.grd_SXBN);
            this.Tab_SapXepBenhNhan.Controls.Add(this.groupBox14);
            this.Tab_SapXepBenhNhan.Controls.Add(this.groupBox13);
            this.Tab_SapXepBenhNhan.Image = ((System.Drawing.Image)(resources.GetObject("Tab_SapXepBenhNhan.Image")));
            this.Tab_SapXepBenhNhan.Name = "Tab_SapXepBenhNhan";
            this.Tab_SapXepBenhNhan.PageVisible = false;
            this.Tab_SapXepBenhNhan.Size = new System.Drawing.Size(1181, 558);
            this.Tab_SapXepBenhNhan.Text = "Sắp Xếp Bệnh Nhân";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.btn_ThemSX);
            this.groupBox13.Controls.Add(this.btn_SuaSX);
            this.groupBox13.Controls.Add(this.btn_XoaSX);
            this.groupBox13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox13.Location = new System.Drawing.Point(0, 0);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(185, 251);
            this.groupBox13.TabIndex = 5;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Chức Năng";
            // 
            // btn_XoaSX
            // 
            this.btn_XoaSX.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_XoaSX.Appearance.Options.UseFont = true;
            this.btn_XoaSX.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_XoaSX.ImageOptions.Image")));
            this.btn_XoaSX.Location = new System.Drawing.Point(6, 163);
            this.btn_XoaSX.Name = "btn_XoaSX";
            this.btn_XoaSX.Size = new System.Drawing.Size(173, 68);
            this.btn_XoaSX.TabIndex = 22;
            this.btn_XoaSX.Text = "Bệnh Nhân Trả Giường";
            this.btn_XoaSX.Click += new System.EventHandler(this.btn_XoaSX_Click);
            // 
            // btn_SuaSX
            // 
            this.btn_SuaSX.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_SuaSX.Appearance.Options.UseFont = true;
            this.btn_SuaSX.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_SuaSX.ImageOptions.Image")));
            this.btn_SuaSX.Location = new System.Drawing.Point(6, 95);
            this.btn_SuaSX.Name = "btn_SuaSX";
            this.btn_SuaSX.Size = new System.Drawing.Size(173, 67);
            this.btn_SuaSX.TabIndex = 25;
            this.btn_SuaSX.Text = "Sửa Thời Điểm \r\n Nằm/Xuất Viện ";
            this.btn_SuaSX.Click += new System.EventHandler(this.btn_SuaSX_Click);
            // 
            // btn_ThemSX
            // 
            this.btn_ThemSX.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_ThemSX.Appearance.Options.UseFont = true;
            this.btn_ThemSX.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_ThemSX.ImageOptions.Image")));
            this.btn_ThemSX.Location = new System.Drawing.Point(6, 33);
            this.btn_ThemSX.Name = "btn_ThemSX";
            this.btn_ThemSX.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_ThemSX.Size = new System.Drawing.Size(173, 63);
            this.btn_ThemSX.TabIndex = 21;
            this.btn_ThemSX.Text = "Đặt Giường Cho\r\n Bệnh Nhân";
            this.btn_ThemSX.Click += new System.EventHandler(this.btn_ThemSX_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label38);
            this.groupBox14.Controls.Add(this.date_TimeXV);
            this.groupBox14.Controls.Add(this.date_TimeNV);
            this.groupBox14.Controls.Add(this.btn_LoadSX);
            this.groupBox14.Controls.Add(this.txt_MSBNSapXep);
            this.groupBox14.Controls.Add(this.txt_MGBSapXep);
            this.groupBox14.Controls.Add(this.label36);
            this.groupBox14.Controls.Add(this.btn_LuuSX);
            this.groupBox14.Controls.Add(this.btn_HuySX);
            this.groupBox14.Controls.Add(this.label39);
            this.groupBox14.Controls.Add(this.label40);
            this.groupBox14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox14.Location = new System.Drawing.Point(184, 0);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(1002, 251);
            this.groupBox14.TabIndex = 9;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Sắp Xếp Giường Cho Bệnh Nhân";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label40.Location = new System.Drawing.Point(182, 33);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(89, 13);
            this.label40.TabIndex = 33;
            this.label40.Text = "Mã Bệnh Nhân:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label39.Location = new System.Drawing.Point(563, 33);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(122, 13);
            this.label39.TabIndex = 34;
            this.label39.Text = "Thời Điểm Nằm Viện:";
            // 
            // btn_HuySX
            // 
            this.btn_HuySX.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_HuySX.Appearance.Options.UseFont = true;
            this.btn_HuySX.Enabled = false;
            this.btn_HuySX.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HuySX.ImageOptions.Image")));
            this.btn_HuySX.Location = new System.Drawing.Point(816, 199);
            this.btn_HuySX.Name = "btn_HuySX";
            this.btn_HuySX.Size = new System.Drawing.Size(112, 32);
            this.btn_HuySX.TabIndex = 41;
            this.btn_HuySX.Text = "Hủy";
            this.btn_HuySX.Click += new System.EventHandler(this.btn_HuySX_Click);
            // 
            // btn_LuuSX
            // 
            this.btn_LuuSX.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LuuSX.Appearance.Options.UseFont = true;
            this.btn_LuuSX.Enabled = false;
            this.btn_LuuSX.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LuuSX.ImageOptions.Image")));
            this.btn_LuuSX.Location = new System.Drawing.Point(470, 198);
            this.btn_LuuSX.Name = "btn_LuuSX";
            this.btn_LuuSX.Size = new System.Drawing.Size(112, 32);
            this.btn_LuuSX.TabIndex = 42;
            this.btn_LuuSX.Text = "Lưu lại";
            this.btn_LuuSX.Click += new System.EventHandler(this.btn_LuuSX_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label36.Location = new System.Drawing.Point(170, 76);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(101, 13);
            this.label36.TabIndex = 46;
            this.label36.Text = "Mã Giường Bệnh:";
            // 
            // txt_MGBSapXep
            // 
            this.txt_MGBSapXep.Location = new System.Drawing.Point(291, 73);
            this.txt_MGBSapXep.MenuManager = this.ribbon;
            this.txt_MGBSapXep.Name = "txt_MGBSapXep";
            this.txt_MGBSapXep.Properties.ReadOnly = true;
            this.txt_MGBSapXep.Size = new System.Drawing.Size(161, 20);
            this.txt_MGBSapXep.TabIndex = 47;
            // 
            // txt_MSBNSapXep
            // 
            this.txt_MSBNSapXep.Location = new System.Drawing.Point(291, 30);
            this.txt_MSBNSapXep.MenuManager = this.ribbon;
            this.txt_MSBNSapXep.Name = "txt_MSBNSapXep";
            this.txt_MSBNSapXep.Properties.ReadOnly = true;
            this.txt_MSBNSapXep.Size = new System.Drawing.Size(161, 20);
            this.txt_MSBNSapXep.TabIndex = 52;
            // 
            // btn_LoadSX
            // 
            this.btn_LoadSX.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LoadSX.Appearance.Options.UseFont = true;
            this.btn_LoadSX.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LoadSX.ImageOptions.Image")));
            this.btn_LoadSX.Location = new System.Drawing.Point(643, 199);
            this.btn_LoadSX.Name = "btn_LoadSX";
            this.btn_LoadSX.Size = new System.Drawing.Size(109, 31);
            this.btn_LoadSX.TabIndex = 53;
            this.btn_LoadSX.Text = "Tải lại";
            this.btn_LoadSX.Click += new System.EventHandler(this.btn_LoadSX_Click);
            // 
            // date_TimeNV
            // 
            this.date_TimeNV.EditValue = null;
            this.date_TimeNV.Location = new System.Drawing.Point(706, 33);
            this.date_TimeNV.MenuManager = this.ribbon;
            this.date_TimeNV.Name = "date_TimeNV";
            this.date_TimeNV.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_TimeNV.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_TimeNV.Properties.ReadOnly = true;
            this.date_TimeNV.Size = new System.Drawing.Size(222, 20);
            this.date_TimeNV.TabIndex = 54;
            // 
            // date_TimeXV
            // 
            this.date_TimeXV.EditValue = null;
            this.date_TimeXV.Location = new System.Drawing.Point(706, 73);
            this.date_TimeXV.MenuManager = this.ribbon;
            this.date_TimeXV.Name = "date_TimeXV";
            this.date_TimeXV.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_TimeXV.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_TimeXV.Properties.ReadOnly = true;
            this.date_TimeXV.Size = new System.Drawing.Size(222, 20);
            this.date_TimeXV.TabIndex = 55;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label38.Location = new System.Drawing.Point(562, 76);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(123, 13);
            this.label38.TabIndex = 56;
            this.label38.Text = "Thời Điểm Xuất Viện:";
            // 
            // grd_SXBN
            // 
            this.grd_SXBN.Location = new System.Drawing.Point(0, 257);
            this.grd_SXBN.MainView = this.gridViewSXBN;
            this.grd_SXBN.MenuManager = this.ribbon;
            this.grd_SXBN.Name = "grd_SXBN";
            this.grd_SXBN.Size = new System.Drawing.Size(1181, 301);
            this.grd_SXBN.TabIndex = 10;
            this.grd_SXBN.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewSXBN});
            // 
            // gridView2
            // 
            this.gridView2.GridControl = this.grd_SXBN;
            this.gridView2.Name = "gridView2";
            // 
            // gridViewSXBN
            // 
            this.gridViewSXBN.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn26,
            this.gridColumn27,
            this.gridColumn28,
            this.gridColumn29});
            this.gridViewSXBN.GridControl = this.grd_SXBN;
            this.gridViewSXBN.Name = "gridViewSXBN";
            this.gridViewSXBN.OptionsView.ShowGroupPanel = false;
            this.gridViewSXBN.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewSXBN_FocusedRowChanged);
            // 
            // gridColumn26
            // 
            this.gridColumn26.Caption = "Mã Bệnh Nhân";
            this.gridColumn26.FieldName = "MaSoBenhNhan";
            this.gridColumn26.Name = "gridColumn26";
            this.gridColumn26.Visible = true;
            this.gridColumn26.VisibleIndex = 0;
            // 
            // gridColumn27
            // 
            this.gridColumn27.Caption = "Mã Giường Bệnh";
            this.gridColumn27.FieldName = "MaGiuongBenh";
            this.gridColumn27.Name = "gridColumn27";
            this.gridColumn27.Visible = true;
            this.gridColumn27.VisibleIndex = 1;
            // 
            // gridColumn28
            // 
            this.gridColumn28.Caption = "Thời Điểm Nằm Viện";
            this.gridColumn28.FieldName = "ThoiDiemNamVien";
            this.gridColumn28.Name = "gridColumn28";
            this.gridColumn28.Visible = true;
            this.gridColumn28.VisibleIndex = 2;
            // 
            // gridColumn29
            // 
            this.gridColumn29.Caption = "Thời Điểm Xuất Viện";
            this.gridColumn29.FieldName = "ThoiDiemXuatVien";
            this.gridColumn29.Name = "gridColumn29";
            this.gridColumn29.Visible = true;
            this.gridColumn29.VisibleIndex = 3;
            // 
            // Tab_PhanCong
            // 
            this.Tab_PhanCong.Controls.Add(this.groupBox12);
            this.Tab_PhanCong.Controls.Add(this.grd_PhanCong);
            this.Tab_PhanCong.Controls.Add(this.groupBox7);
            this.Tab_PhanCong.Image = ((System.Drawing.Image)(resources.GetObject("Tab_PhanCong.Image")));
            this.Tab_PhanCong.Name = "Tab_PhanCong";
            this.Tab_PhanCong.PageVisible = false;
            this.Tab_PhanCong.Size = new System.Drawing.Size(1181, 558);
            this.Tab_PhanCong.Text = "Phân Công";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.date_TimePC);
            this.groupBox7.Controls.Add(this.txt_TienSuBA);
            this.groupBox7.Controls.Add(this.label44);
            this.groupBox7.Controls.Add(this.label43);
            this.groupBox7.Controls.Add(this.btn_LoadPC);
            this.groupBox7.Controls.Add(this.txt_MaBenhNhanPC);
            this.groupBox7.Controls.Add(this.txt_MaBacSyPC);
            this.groupBox7.Controls.Add(this.txt_TinhTrangBN);
            this.groupBox7.Controls.Add(this.txt_NhomMau);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.btn_LuuPC);
            this.groupBox7.Controls.Add(this.btn_HuyPC);
            this.groupBox7.Controls.Add(this.txt_DiUngThuoc);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.label35);
            this.groupBox7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox7.Location = new System.Drawing.Point(185, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1001, 251);
            this.groupBox7.TabIndex = 8;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Quản Lý Phân Công";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label35.Location = new System.Drawing.Point(118, 61);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(89, 13);
            this.label35.TabIndex = 33;
            this.label35.Text = "Mã Bệnh Nhân:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label34.Location = new System.Drawing.Point(121, 133);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(84, 13);
            this.label34.TabIndex = 34;
            this.label34.Text = "Dị Ứng Thuốc:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label33.Location = new System.Drawing.Point(140, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 13);
            this.label33.TabIndex = 35;
            this.label33.Text = "Mã Bác Sỹ:";
            // 
            // txt_DiUngThuoc
            // 
            this.txt_DiUngThuoc.Location = new System.Drawing.Point(234, 130);
            this.txt_DiUngThuoc.MenuManager = this.ribbon;
            this.txt_DiUngThuoc.Name = "txt_DiUngThuoc";
            this.txt_DiUngThuoc.Properties.ReadOnly = true;
            this.txt_DiUngThuoc.Size = new System.Drawing.Size(222, 20);
            this.txt_DiUngThuoc.TabIndex = 39;
            // 
            // btn_HuyPC
            // 
            this.btn_HuyPC.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_HuyPC.Appearance.Options.UseFont = true;
            this.btn_HuyPC.Enabled = false;
            this.btn_HuyPC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HuyPC.ImageOptions.Image")));
            this.btn_HuyPC.Location = new System.Drawing.Point(730, 185);
            this.btn_HuyPC.Name = "btn_HuyPC";
            this.btn_HuyPC.Size = new System.Drawing.Size(112, 32);
            this.btn_HuyPC.TabIndex = 41;
            this.btn_HuyPC.Text = "Hủy";
            this.btn_HuyPC.Click += new System.EventHandler(this.btn_HuyPC_Click);
            // 
            // btn_LuuPC
            // 
            this.btn_LuuPC.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LuuPC.Appearance.Options.UseFont = true;
            this.btn_LuuPC.Enabled = false;
            this.btn_LuuPC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LuuPC.ImageOptions.Image")));
            this.btn_LuuPC.Location = new System.Drawing.Point(418, 185);
            this.btn_LuuPC.Name = "btn_LuuPC";
            this.btn_LuuPC.Size = new System.Drawing.Size(112, 32);
            this.btn_LuuPC.TabIndex = 42;
            this.btn_LuuPC.Text = "Lưu lại";
            this.btn_LuuPC.Click += new System.EventHandler(this.btn_LuuPC_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label32.Location = new System.Drawing.Point(551, 61);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(132, 13);
            this.label32.TabIndex = 44;
            this.label32.Text = "Tình Trạng Bệnh Nhân:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label31.Location = new System.Drawing.Point(136, 97);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(69, 13);
            this.label31.TabIndex = 46;
            this.label31.Text = "Nhóm Máu:";
            // 
            // txt_NhomMau
            // 
            this.txt_NhomMau.Location = new System.Drawing.Point(234, 94);
            this.txt_NhomMau.MenuManager = this.ribbon;
            this.txt_NhomMau.Name = "txt_NhomMau";
            this.txt_NhomMau.Properties.ReadOnly = true;
            this.txt_NhomMau.Size = new System.Drawing.Size(222, 20);
            this.txt_NhomMau.TabIndex = 47;
            // 
            // txt_TinhTrangBN
            // 
            this.txt_TinhTrangBN.Location = new System.Drawing.Point(707, 58);
            this.txt_TinhTrangBN.MenuManager = this.ribbon;
            this.txt_TinhTrangBN.Name = "txt_TinhTrangBN";
            this.txt_TinhTrangBN.Properties.ReadOnly = true;
            this.txt_TinhTrangBN.Size = new System.Drawing.Size(222, 20);
            this.txt_TinhTrangBN.TabIndex = 48;
            // 
            // txt_MaBacSyPC
            // 
            this.txt_MaBacSyPC.Location = new System.Drawing.Point(234, 20);
            this.txt_MaBacSyPC.MenuManager = this.ribbon;
            this.txt_MaBacSyPC.Name = "txt_MaBacSyPC";
            this.txt_MaBacSyPC.Properties.ReadOnly = true;
            this.txt_MaBacSyPC.Size = new System.Drawing.Size(222, 20);
            this.txt_MaBacSyPC.TabIndex = 51;
            // 
            // txt_MaBenhNhanPC
            // 
            this.txt_MaBenhNhanPC.Location = new System.Drawing.Point(234, 58);
            this.txt_MaBenhNhanPC.MenuManager = this.ribbon;
            this.txt_MaBenhNhanPC.Name = "txt_MaBenhNhanPC";
            this.txt_MaBenhNhanPC.Properties.ReadOnly = true;
            this.txt_MaBenhNhanPC.Size = new System.Drawing.Size(222, 20);
            this.txt_MaBenhNhanPC.TabIndex = 52;
            // 
            // btn_LoadPC
            // 
            this.btn_LoadPC.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LoadPC.Appearance.Options.UseFont = true;
            this.btn_LoadPC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LoadPC.ImageOptions.Image")));
            this.btn_LoadPC.Location = new System.Drawing.Point(574, 186);
            this.btn_LoadPC.Name = "btn_LoadPC";
            this.btn_LoadPC.Size = new System.Drawing.Size(109, 31);
            this.btn_LoadPC.TabIndex = 53;
            this.btn_LoadPC.Text = "Tải lại";
            this.btn_LoadPC.Click += new System.EventHandler(this.btn_LoadPC_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label43.Location = new System.Drawing.Point(554, 97);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(129, 13);
            this.label43.TabIndex = 54;
            this.label43.Text = "Thời Điểm Phân Công:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label44.Location = new System.Drawing.Point(582, 23);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(101, 13);
            this.label44.TabIndex = 55;
            this.label44.Text = "Tiền Sử Bệnh Án:";
            // 
            // txt_TienSuBA
            // 
            this.txt_TienSuBA.Location = new System.Drawing.Point(707, 20);
            this.txt_TienSuBA.MenuManager = this.ribbon;
            this.txt_TienSuBA.Name = "txt_TienSuBA";
            this.txt_TienSuBA.Properties.ReadOnly = true;
            this.txt_TienSuBA.Size = new System.Drawing.Size(222, 20);
            this.txt_TienSuBA.TabIndex = 56;
            // 
            // date_TimePC
            // 
            this.date_TimePC.EditValue = null;
            this.date_TimePC.Location = new System.Drawing.Point(707, 94);
            this.date_TimePC.MenuManager = this.ribbon;
            this.date_TimePC.Name = "date_TimePC";
            this.date_TimePC.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_TimePC.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.date_TimePC.Properties.ReadOnly = true;
            this.date_TimePC.Size = new System.Drawing.Size(222, 20);
            this.date_TimePC.TabIndex = 57;
            // 
            // grd_PhanCong
            // 
            this.grd_PhanCong.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grd_PhanCong.Location = new System.Drawing.Point(0, 257);
            this.grd_PhanCong.MainView = this.gridViewPhanCong;
            this.grd_PhanCong.MenuManager = this.ribbon;
            this.grd_PhanCong.Name = "grd_PhanCong";
            this.grd_PhanCong.Size = new System.Drawing.Size(1181, 301);
            this.grd_PhanCong.TabIndex = 9;
            this.grd_PhanCong.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewPhanCong});
            // 
            // gridView3
            // 
            this.gridView3.GridControl = this.grd_PhanCong;
            this.gridView3.Name = "gridView3";
            // 
            // gridViewPhanCong
            // 
            this.gridViewPhanCong.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn24,
            this.gridColumn25,
            this.gridColumn5,
            this.gridColumn6});
            this.gridViewPhanCong.GridControl = this.grd_PhanCong;
            this.gridViewPhanCong.Name = "gridViewPhanCong";
            this.gridViewPhanCong.OptionsBehavior.ReadOnly = true;
            this.gridViewPhanCong.OptionsView.ShowGroupPanel = false;
            this.gridViewPhanCong.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.gridViewPhanCong_RowCellClick);
            this.gridViewPhanCong.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewPhanCong_FocusedRowChanged);
            // 
            // gridColumn21
            // 
            this.gridColumn21.Caption = "Mã Bác Sỹ";
            this.gridColumn21.FieldName = "MaBacSy";
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 0;
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "Mã Bệnh Nhân";
            this.gridColumn22.FieldName = "MaSoBenhNhan";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 1;
            // 
            // gridColumn23
            // 
            this.gridColumn23.Caption = "Nhóm Máu";
            this.gridColumn23.FieldName = "NhomMau";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 2;
            // 
            // gridColumn24
            // 
            this.gridColumn24.Caption = "Dị Ứng Thuốc";
            this.gridColumn24.FieldName = "DiUngThuoc";
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 3;
            // 
            // gridColumn25
            // 
            this.gridColumn25.Caption = "Tình Trạng Bệnh Nhân";
            this.gridColumn25.FieldName = "TinhTrangBenhNhan";
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 4;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "Tiền Sử Bệnh Án";
            this.gridColumn5.FieldName = "TienSuBenhAn";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 5;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "Thời Điểm Phân Công";
            this.gridColumn6.FieldName = "ThoiDiemPhanCong";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 6;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btn_ThemPC);
            this.groupBox12.Controls.Add(this.btn_SuaPC);
            this.groupBox12.Controls.Add(this.btn_XoaPC);
            this.groupBox12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox12.Location = new System.Drawing.Point(0, 0);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(185, 251);
            this.groupBox12.TabIndex = 10;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Chức Năng";
            // 
            // btn_XoaPC
            // 
            this.btn_XoaPC.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_XoaPC.Appearance.Options.UseFont = true;
            this.btn_XoaPC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_XoaPC.ImageOptions.Image")));
            this.btn_XoaPC.Location = new System.Drawing.Point(6, 160);
            this.btn_XoaPC.Name = "btn_XoaPC";
            this.btn_XoaPC.Size = new System.Drawing.Size(173, 66);
            this.btn_XoaPC.TabIndex = 40;
            this.btn_XoaPC.Text = "Xóa Phân Công\r\n Điều Trị";
            this.btn_XoaPC.Click += new System.EventHandler(this.btn_XoaPC_Click);
            // 
            // btn_SuaPC
            // 
            this.btn_SuaPC.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_SuaPC.Appearance.Options.UseFont = true;
            this.btn_SuaPC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_SuaPC.ImageOptions.Image")));
            this.btn_SuaPC.Location = new System.Drawing.Point(6, 94);
            this.btn_SuaPC.Name = "btn_SuaPC";
            this.btn_SuaPC.Size = new System.Drawing.Size(173, 66);
            this.btn_SuaPC.TabIndex = 43;
            this.btn_SuaPC.Text = "Thay Đổi Thông Số\r\n Bệnh Nhân";
            this.btn_SuaPC.Click += new System.EventHandler(this.btn_SuaPC_Click);
            // 
            // btn_ThemPC
            // 
            this.btn_ThemPC.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_ThemPC.Appearance.Options.UseFont = true;
            this.btn_ThemPC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_ThemPC.ImageOptions.Image")));
            this.btn_ThemPC.Location = new System.Drawing.Point(6, 33);
            this.btn_ThemPC.Name = "btn_ThemPC";
            this.btn_ThemPC.Size = new System.Drawing.Size(173, 63);
            this.btn_ThemPC.TabIndex = 45;
            this.btn_ThemPC.Text = "Phân Công Bác Sỹ\r\n Điều Trị";
            this.btn_ThemPC.Click += new System.EventHandler(this.btn_ThemPC_Click);
            // 
            // Tab_PhongBenh
            // 
            this.Tab_PhongBenh.Controls.Add(this.groupBox11);
            this.Tab_PhongBenh.Controls.Add(this.grd_PhongBenh);
            this.Tab_PhongBenh.Controls.Add(this.groupBox6);
            this.Tab_PhongBenh.Image = ((System.Drawing.Image)(resources.GetObject("Tab_PhongBenh.Image")));
            this.Tab_PhongBenh.Name = "Tab_PhongBenh";
            this.Tab_PhongBenh.PageVisible = false;
            this.Tab_PhongBenh.Size = new System.Drawing.Size(1181, 558);
            this.Tab_PhongBenh.Text = "Phòng Bệnh";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btn_LoadPB);
            this.groupBox6.Controls.Add(this.txt_LoaiPhong);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.btn_LuuPB);
            this.groupBox6.Controls.Add(this.btn_HuyPB);
            this.groupBox6.Controls.Add(this.txt_SoGiuongBenh);
            this.groupBox6.Controls.Add(this.txt_TenPhongBenh);
            this.groupBox6.Controls.Add(this.txt_MaPB);
            this.groupBox6.Controls.Add(this.checkE_PhongBenh);
            this.groupBox6.Controls.Add(this.label27);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox6.Location = new System.Drawing.Point(185, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1001, 251);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Quản Lý Phòng Bệnh";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label29.Location = new System.Drawing.Point(168, 72);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(69, 13);
            this.label29.TabIndex = 33;
            this.label29.Text = "Tên Phòng:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label28.Location = new System.Drawing.Point(522, 35);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(98, 13);
            this.label28.TabIndex = 34;
            this.label28.Text = "Số Giường Bệnh:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label27.Location = new System.Drawing.Point(141, 35);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(96, 13);
            this.label27.TabIndex = 35;
            this.label27.Text = "Mã Phòng Bệnh:";
            // 
            // checkE_PhongBenh
            // 
            this.checkE_PhongBenh.Location = new System.Drawing.Point(650, 70);
            this.checkE_PhongBenh.MenuManager = this.ribbon;
            this.checkE_PhongBenh.Name = "checkE_PhongBenh";
            this.checkE_PhongBenh.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.checkE_PhongBenh.Properties.Appearance.Options.UseFont = true;
            this.checkE_PhongBenh.Properties.Caption = "";
            this.checkE_PhongBenh.Properties.ReadOnly = true;
            this.checkE_PhongBenh.Size = new System.Drawing.Size(44, 19);
            this.checkE_PhongBenh.TabIndex = 36;
            // 
            // txt_MaPB
            // 
            this.txt_MaPB.Location = new System.Drawing.Point(264, 32);
            this.txt_MaPB.MenuManager = this.ribbon;
            this.txt_MaPB.Name = "txt_MaPB";
            this.txt_MaPB.Properties.ReadOnly = true;
            this.txt_MaPB.Size = new System.Drawing.Size(161, 20);
            this.txt_MaPB.TabIndex = 37;
            // 
            // txt_TenPhongBenh
            // 
            this.txt_TenPhongBenh.Location = new System.Drawing.Point(264, 69);
            this.txt_TenPhongBenh.MenuManager = this.ribbon;
            this.txt_TenPhongBenh.Name = "txt_TenPhongBenh";
            this.txt_TenPhongBenh.Properties.ReadOnly = true;
            this.txt_TenPhongBenh.Size = new System.Drawing.Size(161, 20);
            this.txt_TenPhongBenh.TabIndex = 38;
            // 
            // txt_SoGiuongBenh
            // 
            this.txt_SoGiuongBenh.Location = new System.Drawing.Point(650, 32);
            this.txt_SoGiuongBenh.MenuManager = this.ribbon;
            this.txt_SoGiuongBenh.Name = "txt_SoGiuongBenh";
            this.txt_SoGiuongBenh.Properties.ReadOnly = true;
            this.txt_SoGiuongBenh.Size = new System.Drawing.Size(207, 20);
            this.txt_SoGiuongBenh.TabIndex = 39;
            // 
            // btn_HuyPB
            // 
            this.btn_HuyPB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_HuyPB.Appearance.Options.UseFont = true;
            this.btn_HuyPB.Enabled = false;
            this.btn_HuyPB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HuyPB.ImageOptions.Image")));
            this.btn_HuyPB.Location = new System.Drawing.Point(744, 192);
            this.btn_HuyPB.Name = "btn_HuyPB";
            this.btn_HuyPB.Size = new System.Drawing.Size(113, 32);
            this.btn_HuyPB.TabIndex = 41;
            this.btn_HuyPB.Text = "Hủy";
            this.btn_HuyPB.Click += new System.EventHandler(this.btn_HuyPB_Click);
            // 
            // btn_LuuPB
            // 
            this.btn_LuuPB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LuuPB.Appearance.Options.UseFont = true;
            this.btn_LuuPB.Enabled = false;
            this.btn_LuuPB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LuuPB.ImageOptions.Image")));
            this.btn_LuuPB.Location = new System.Drawing.Point(425, 192);
            this.btn_LuuPB.Name = "btn_LuuPB";
            this.btn_LuuPB.Size = new System.Drawing.Size(117, 32);
            this.btn_LuuPB.TabIndex = 42;
            this.btn_LuuPB.Text = "Lưu lại";
            this.btn_LuuPB.Click += new System.EventHandler(this.btn_LuuPB_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label26.Location = new System.Drawing.Point(492, 72);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(128, 13);
            this.label26.TabIndex = 44;
            this.label26.Text = "Phòng Sử Dụng Được:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label30.Location = new System.Drawing.Point(166, 109);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(71, 13);
            this.label30.TabIndex = 46;
            this.label30.Text = "Loại Phòng:";
            // 
            // txt_LoaiPhong
            // 
            this.txt_LoaiPhong.Location = new System.Drawing.Point(264, 106);
            this.txt_LoaiPhong.MenuManager = this.ribbon;
            this.txt_LoaiPhong.Name = "txt_LoaiPhong";
            this.txt_LoaiPhong.Properties.ReadOnly = true;
            this.txt_LoaiPhong.Size = new System.Drawing.Size(161, 20);
            this.txt_LoaiPhong.TabIndex = 47;
            // 
            // btn_LoadPB
            // 
            this.btn_LoadPB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LoadPB.Appearance.Options.UseFont = true;
            this.btn_LoadPB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LoadPB.ImageOptions.Image")));
            this.btn_LoadPB.Location = new System.Drawing.Point(585, 192);
            this.btn_LoadPB.Name = "btn_LoadPB";
            this.btn_LoadPB.Size = new System.Drawing.Size(109, 32);
            this.btn_LoadPB.TabIndex = 48;
            this.btn_LoadPB.Text = "Tải lại";
            this.btn_LoadPB.Click += new System.EventHandler(this.btn_LoadPB_Click);
            // 
            // grd_PhongBenh
            // 
            this.grd_PhongBenh.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grd_PhongBenh.Location = new System.Drawing.Point(0, 257);
            this.grd_PhongBenh.MainView = this.gridViewPhongBenh;
            this.grd_PhongBenh.MenuManager = this.ribbon;
            this.grd_PhongBenh.Name = "grd_PhongBenh";
            this.grd_PhongBenh.Size = new System.Drawing.Size(1181, 301);
            this.grd_PhongBenh.TabIndex = 8;
            this.grd_PhongBenh.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewPhongBenh});
            // 
            // gridView4
            // 
            this.gridView4.GridControl = this.grd_PhongBenh;
            this.gridView4.Name = "gridView4";
            // 
            // gridViewPhongBenh
            // 
            this.gridViewPhongBenh.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn18,
            this.gridColumn19,
            this.gridColumn20});
            this.gridViewPhongBenh.GridControl = this.grd_PhongBenh;
            this.gridViewPhongBenh.Name = "gridViewPhongBenh";
            this.gridViewPhongBenh.OptionsBehavior.ReadOnly = true;
            this.gridViewPhongBenh.OptionsView.ShowGroupPanel = false;
            this.gridViewPhongBenh.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.gridViewPhongBenh_RowCellClick);
            this.gridViewPhongBenh.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewPhongBenh_FocusedRowChanged);
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "Mã Phòng Bệnh";
            this.gridColumn16.FieldName = "MaPhongBenh";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 0;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "Tên Phòng";
            this.gridColumn17.FieldName = "TenPhong";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 1;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "Loại Phòng";
            this.gridColumn18.FieldName = "LoaiPhong";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 2;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "Số Giường";
            this.gridColumn19.FieldName = "SoGiuong";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 3;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "Phòng Sử Dụng Được";
            this.gridColumn20.FieldName = "PhongSuDungDuoc";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 4;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btn_ThemPB);
            this.groupBox11.Controls.Add(this.btn_SuaPB);
            this.groupBox11.Controls.Add(this.btn_XoaPB);
            this.groupBox11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox11.Location = new System.Drawing.Point(0, 0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(185, 251);
            this.groupBox11.TabIndex = 9;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Chức Năng";
            // 
            // btn_XoaPB
            // 
            this.btn_XoaPB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_XoaPB.Appearance.Options.UseFont = true;
            this.btn_XoaPB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_XoaPB.ImageOptions.Image")));
            this.btn_XoaPB.Location = new System.Drawing.Point(6, 162);
            this.btn_XoaPB.Name = "btn_XoaPB";
            this.btn_XoaPB.Size = new System.Drawing.Size(173, 72);
            this.btn_XoaPB.TabIndex = 40;
            this.btn_XoaPB.Text = "Xóa Thông Tin\r\n Phòng Bệnh\r\n";
            this.btn_XoaPB.Click += new System.EventHandler(this.btn_XoaPB_Click);
            // 
            // btn_SuaPB
            // 
            this.btn_SuaPB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_SuaPB.Appearance.Options.UseFont = true;
            this.btn_SuaPB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_SuaPB.ImageOptions.Image")));
            this.btn_SuaPB.Location = new System.Drawing.Point(6, 95);
            this.btn_SuaPB.Name = "btn_SuaPB";
            this.btn_SuaPB.Size = new System.Drawing.Size(173, 71);
            this.btn_SuaPB.TabIndex = 43;
            this.btn_SuaPB.Text = "Sửa Thông Tin\r\n Phòng Bệnh";
            this.btn_SuaPB.Click += new System.EventHandler(this.btn_SuaPB_Click);
            // 
            // btn_ThemPB
            // 
            this.btn_ThemPB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_ThemPB.Appearance.Options.UseFont = true;
            this.btn_ThemPB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_ThemPB.ImageOptions.Image")));
            this.btn_ThemPB.Location = new System.Drawing.Point(6, 35);
            this.btn_ThemPB.Name = "btn_ThemPB";
            this.btn_ThemPB.Size = new System.Drawing.Size(173, 63);
            this.btn_ThemPB.TabIndex = 45;
            this.btn_ThemPB.Text = "Thêm Thông Tin\r\n Phòng Bệnh";
            this.btn_ThemPB.Click += new System.EventHandler(this.btn_ThemPB_Click);
            // 
            // Tab_GiuongBenh
            // 
            this.Tab_GiuongBenh.Controls.Add(this.groupBox10);
            this.Tab_GiuongBenh.Controls.Add(this.groupBox5);
            this.Tab_GiuongBenh.Controls.Add(this.grd_GiuongBenh);
            this.Tab_GiuongBenh.Image = ((System.Drawing.Image)(resources.GetObject("Tab_GiuongBenh.Image")));
            this.Tab_GiuongBenh.Name = "Tab_GiuongBenh";
            this.Tab_GiuongBenh.PageVisible = false;
            this.Tab_GiuongBenh.Size = new System.Drawing.Size(1181, 558);
            this.Tab_GiuongBenh.Text = "Giường Bệnh";
            // 
            // grd_GiuongBenh
            // 
            this.grd_GiuongBenh.Location = new System.Drawing.Point(0, 257);
            this.grd_GiuongBenh.MainView = this.gridViewGiuongBenh;
            this.grd_GiuongBenh.MenuManager = this.ribbon;
            this.grd_GiuongBenh.Name = "grd_GiuongBenh";
            this.grd_GiuongBenh.Size = new System.Drawing.Size(1186, 314);
            this.grd_GiuongBenh.TabIndex = 5;
            this.grd_GiuongBenh.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewGiuongBenh});
            // 
            // gridView5
            // 
            this.gridView5.GridControl = this.grd_GiuongBenh;
            this.gridView5.Name = "gridView5";
            // 
            // gridViewGiuongBenh
            // 
            this.gridViewGiuongBenh.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15});
            this.gridViewGiuongBenh.GridControl = this.grd_GiuongBenh;
            this.gridViewGiuongBenh.Name = "gridViewGiuongBenh";
            this.gridViewGiuongBenh.OptionsBehavior.ReadOnly = true;
            this.gridViewGiuongBenh.OptionsView.ShowGroupPanel = false;
            this.gridViewGiuongBenh.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.gridViewGiuongBenh_RowCellClick);
            this.gridViewGiuongBenh.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewGiuongBenh_FocusedRowChanged);
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "Mã Giường Bệnh";
            this.gridColumn12.FieldName = "MaGiuongBenh";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 0;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "Loại Giường";
            this.gridColumn13.FieldName = "LoaiGiuong";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 1;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "Mã Phòng Bệnh";
            this.gridColumn14.FieldName = "MaPhongBenh";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 2;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "Đã Có Người Nằm";
            this.gridColumn15.FieldName = "DaCoNguoiNam";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 3;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txt_MaPhong);
            this.groupBox5.Controls.Add(this.btn_LoadGB);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.btn_LuuGB);
            this.groupBox5.Controls.Add(this.btn_HuyGB);
            this.groupBox5.Controls.Add(this.txt_LoaiGiuongBenh);
            this.groupBox5.Controls.Add(this.txt_MaGiuongBenh);
            this.groupBox5.Controls.Add(this.checkE_NguoiNam);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox5.Location = new System.Drawing.Point(185, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1001, 251);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Quản Lý Giường Bệnh";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(150, 69);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(96, 13);
            this.label23.TabIndex = 33;
            this.label23.Text = "Mã Phòng Bệnh:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(530, 32);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(107, 13);
            this.label24.TabIndex = 34;
            this.label24.Text = "Loại Giường Bệnh:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(149, 32);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(101, 13);
            this.label25.TabIndex = 35;
            this.label25.Text = "Mã Giường Bệnh:";
            // 
            // checkE_NguoiNam
            // 
            this.checkE_NguoiNam.Location = new System.Drawing.Point(658, 67);
            this.checkE_NguoiNam.MenuManager = this.ribbon;
            this.checkE_NguoiNam.Name = "checkE_NguoiNam";
            this.checkE_NguoiNam.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.checkE_NguoiNam.Properties.Appearance.Options.UseFont = true;
            this.checkE_NguoiNam.Properties.Caption = "";
            this.checkE_NguoiNam.Properties.ReadOnly = true;
            this.checkE_NguoiNam.Size = new System.Drawing.Size(44, 19);
            this.checkE_NguoiNam.TabIndex = 36;
            // 
            // txt_MaGiuongBenh
            // 
            this.txt_MaGiuongBenh.Location = new System.Drawing.Point(272, 29);
            this.txt_MaGiuongBenh.MenuManager = this.ribbon;
            this.txt_MaGiuongBenh.Name = "txt_MaGiuongBenh";
            this.txt_MaGiuongBenh.Properties.ReadOnly = true;
            this.txt_MaGiuongBenh.Size = new System.Drawing.Size(185, 20);
            this.txt_MaGiuongBenh.TabIndex = 37;
            // 
            // txt_LoaiGiuongBenh
            // 
            this.txt_LoaiGiuongBenh.Location = new System.Drawing.Point(658, 29);
            this.txt_LoaiGiuongBenh.MenuManager = this.ribbon;
            this.txt_LoaiGiuongBenh.Name = "txt_LoaiGiuongBenh";
            this.txt_LoaiGiuongBenh.Properties.ReadOnly = true;
            this.txt_LoaiGiuongBenh.Size = new System.Drawing.Size(207, 20);
            this.txt_LoaiGiuongBenh.TabIndex = 39;
            // 
            // btn_HuyGB
            // 
            this.btn_HuyGB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_HuyGB.Appearance.Options.UseFont = true;
            this.btn_HuyGB.Enabled = false;
            this.btn_HuyGB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HuyGB.ImageOptions.Image")));
            this.btn_HuyGB.Location = new System.Drawing.Point(750, 189);
            this.btn_HuyGB.Name = "btn_HuyGB";
            this.btn_HuyGB.Size = new System.Drawing.Size(112, 32);
            this.btn_HuyGB.TabIndex = 41;
            this.btn_HuyGB.Text = "Hủy";
            this.btn_HuyGB.Click += new System.EventHandler(this.btn_HuyGB_Click);
            // 
            // btn_LuuGB
            // 
            this.btn_LuuGB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LuuGB.Appearance.Options.UseFont = true;
            this.btn_LuuGB.Enabled = false;
            this.btn_LuuGB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LuuGB.ImageOptions.Image")));
            this.btn_LuuGB.Location = new System.Drawing.Point(403, 189);
            this.btn_LuuGB.Name = "btn_LuuGB";
            this.btn_LuuGB.Size = new System.Drawing.Size(109, 32);
            this.btn_LuuGB.TabIndex = 42;
            this.btn_LuuGB.Text = "Lưu lại";
            this.btn_LuuGB.Click += new System.EventHandler(this.btn_LuuGB_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(530, 69);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(106, 13);
            this.label22.TabIndex = 44;
            this.label22.Text = "Đã Có Người Nằm:";
            // 
            // btn_LoadGB
            // 
            this.btn_LoadGB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LoadGB.Appearance.Options.UseFont = true;
            this.btn_LoadGB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LoadGB.ImageOptions.Image")));
            this.btn_LoadGB.Location = new System.Drawing.Point(576, 189);
            this.btn_LoadGB.Name = "btn_LoadGB";
            this.btn_LoadGB.Size = new System.Drawing.Size(109, 32);
            this.btn_LoadGB.TabIndex = 45;
            this.btn_LoadGB.Text = "Tải lại";
            this.btn_LoadGB.Click += new System.EventHandler(this.btn_LoadGB_Click);
            // 
            // txt_MaPhong
            // 
            this.txt_MaPhong.Location = new System.Drawing.Point(272, 66);
            this.txt_MaPhong.MenuManager = this.ribbon;
            this.txt_MaPhong.Name = "txt_MaPhong";
            this.txt_MaPhong.Properties.ReadOnly = true;
            this.txt_MaPhong.Size = new System.Drawing.Size(185, 20);
            this.txt_MaPhong.TabIndex = 47;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btn_ThemGB);
            this.groupBox10.Controls.Add(this.btn_SuaGB);
            this.groupBox10.Controls.Add(this.btn_XoaGB);
            this.groupBox10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox10.Location = new System.Drawing.Point(0, 0);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(185, 251);
            this.groupBox10.TabIndex = 7;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Chức Năng";
            // 
            // btn_XoaGB
            // 
            this.btn_XoaGB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_XoaGB.Appearance.Options.UseFont = true;
            this.btn_XoaGB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_XoaGB.ImageOptions.Image")));
            this.btn_XoaGB.Location = new System.Drawing.Point(6, 153);
            this.btn_XoaGB.Name = "btn_XoaGB";
            this.btn_XoaGB.Size = new System.Drawing.Size(173, 68);
            this.btn_XoaGB.TabIndex = 40;
            this.btn_XoaGB.Text = "Xóa Giường Bệnh";
            this.btn_XoaGB.Click += new System.EventHandler(this.btn_XoaGB_Click);
            // 
            // btn_SuaGB
            // 
            this.btn_SuaGB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_SuaGB.Appearance.Options.UseFont = true;
            this.btn_SuaGB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_SuaGB.ImageOptions.Image")));
            this.btn_SuaGB.Location = new System.Drawing.Point(6, 88);
            this.btn_SuaGB.Name = "btn_SuaGB";
            this.btn_SuaGB.Size = new System.Drawing.Size(173, 68);
            this.btn_SuaGB.TabIndex = 43;
            this.btn_SuaGB.Text = "Sửa Giường Bệnh";
            this.btn_SuaGB.Click += new System.EventHandler(this.btn_SuaGB_Click);
            // 
            // btn_ThemGB
            // 
            this.btn_ThemGB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_ThemGB.Appearance.Options.UseFont = true;
            this.btn_ThemGB.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_ThemGB.ImageOptions.Image")));
            this.btn_ThemGB.Location = new System.Drawing.Point(6, 20);
            this.btn_ThemGB.Name = "btn_ThemGB";
            this.btn_ThemGB.Size = new System.Drawing.Size(173, 66);
            this.btn_ThemGB.TabIndex = 45;
            this.btn_ThemGB.Text = "Thêm Giường Bệnh";
            this.btn_ThemGB.Click += new System.EventHandler(this.btn_ThemGB_Click);
            // 
            // Tab_BenhNhan
            // 
            this.Tab_BenhNhan.Controls.Add(this.groupBox9);
            this.Tab_BenhNhan.Controls.Add(this.groupBox4);
            this.Tab_BenhNhan.Controls.Add(this.grd_BenhNhan);
            this.Tab_BenhNhan.Controls.Add(this.groupBox3);
            this.Tab_BenhNhan.Image = ((System.Drawing.Image)(resources.GetObject("Tab_BenhNhan.Image")));
            this.Tab_BenhNhan.Name = "Tab_BenhNhan";
            this.Tab_BenhNhan.PageVisible = false;
            this.Tab_BenhNhan.Size = new System.Drawing.Size(1181, 558);
            this.Tab_BenhNhan.Text = "Bệnh Nhân";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_LoadBN);
            this.groupBox3.Controls.Add(this.txt_NoiSinhBN);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.btn_LuuBN);
            this.groupBox3.Controls.Add(this.btn_HuyBN);
            this.groupBox3.Controls.Add(this.det_NgaySinhBN);
            this.groupBox3.Controls.Add(this.rdb_NuBN);
            this.groupBox3.Controls.Add(this.rdb_NamBN);
            this.groupBox3.Controls.Add(this.txt_HoTenBN);
            this.groupBox3.Controls.Add(this.txt_CMNDBN);
            this.groupBox3.Controls.Add(this.txt_DiaChiBN);
            this.groupBox3.Controls.Add(this.txt_SdtBN);
            this.groupBox3.Controls.Add(this.txt_NgheNghiepBN);
            this.groupBox3.Controls.Add(this.txt_EmailBN);
            this.groupBox3.Controls.Add(this.txt_MaBN);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Location = new System.Drawing.Point(185, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1000, 251);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Quản Lý Bệnh Nhân";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(127, 26);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(89, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "Mã Bệnh Nhân:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(167, 58);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Họ Tên:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(596, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "CMND:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(559, 162);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Nghề Nghiệp:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label16.Location = new System.Drawing.Point(589, 58);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Địa Chỉ:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(598, 127);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "Email:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(551, 92);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Số Điện Thoại:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(158, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "Giới Tính:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(151, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Ngày Sinh:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_MaBN
            // 
            this.txt_MaBN.Location = new System.Drawing.Point(237, 23);
            this.txt_MaBN.MenuManager = this.ribbon;
            this.txt_MaBN.Name = "txt_MaBN";
            this.txt_MaBN.Properties.ReadOnly = true;
            this.txt_MaBN.Size = new System.Drawing.Size(190, 20);
            this.txt_MaBN.TabIndex = 10;
            // 
            // txt_EmailBN
            // 
            this.txt_EmailBN.Location = new System.Drawing.Point(663, 124);
            this.txt_EmailBN.MenuManager = this.ribbon;
            this.txt_EmailBN.Name = "txt_EmailBN";
            this.txt_EmailBN.Properties.ReadOnly = true;
            this.txt_EmailBN.Size = new System.Drawing.Size(269, 20);
            this.txt_EmailBN.TabIndex = 11;
            // 
            // txt_NgheNghiepBN
            // 
            this.txt_NgheNghiepBN.Location = new System.Drawing.Point(663, 159);
            this.txt_NgheNghiepBN.MenuManager = this.ribbon;
            this.txt_NgheNghiepBN.Name = "txt_NgheNghiepBN";
            this.txt_NgheNghiepBN.Properties.ReadOnly = true;
            this.txt_NgheNghiepBN.Size = new System.Drawing.Size(269, 20);
            this.txt_NgheNghiepBN.TabIndex = 12;
            // 
            // txt_SdtBN
            // 
            this.txt_SdtBN.Location = new System.Drawing.Point(663, 89);
            this.txt_SdtBN.MenuManager = this.ribbon;
            this.txt_SdtBN.Name = "txt_SdtBN";
            this.txt_SdtBN.Properties.ReadOnly = true;
            this.txt_SdtBN.Size = new System.Drawing.Size(269, 20);
            this.txt_SdtBN.TabIndex = 13;
            // 
            // txt_DiaChiBN
            // 
            this.txt_DiaChiBN.Location = new System.Drawing.Point(663, 55);
            this.txt_DiaChiBN.MenuManager = this.ribbon;
            this.txt_DiaChiBN.Name = "txt_DiaChiBN";
            this.txt_DiaChiBN.Properties.ReadOnly = true;
            this.txt_DiaChiBN.Size = new System.Drawing.Size(269, 20);
            this.txt_DiaChiBN.TabIndex = 14;
            // 
            // txt_CMNDBN
            // 
            this.txt_CMNDBN.Location = new System.Drawing.Point(663, 23);
            this.txt_CMNDBN.MenuManager = this.ribbon;
            this.txt_CMNDBN.Name = "txt_CMNDBN";
            this.txt_CMNDBN.Properties.ReadOnly = true;
            this.txt_CMNDBN.Size = new System.Drawing.Size(269, 20);
            this.txt_CMNDBN.TabIndex = 15;
            // 
            // txt_HoTenBN
            // 
            this.txt_HoTenBN.Location = new System.Drawing.Point(237, 55);
            this.txt_HoTenBN.MenuManager = this.ribbon;
            this.txt_HoTenBN.Name = "txt_HoTenBN";
            this.txt_HoTenBN.Properties.ReadOnly = true;
            this.txt_HoTenBN.Size = new System.Drawing.Size(190, 20);
            this.txt_HoTenBN.TabIndex = 16;
            // 
            // rdb_NamBN
            // 
            this.rdb_NamBN.AutoSize = true;
            this.rdb_NamBN.Enabled = false;
            this.rdb_NamBN.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rdb_NamBN.Location = new System.Drawing.Point(237, 90);
            this.rdb_NamBN.Name = "rdb_NamBN";
            this.rdb_NamBN.Size = new System.Drawing.Size(50, 17);
            this.rdb_NamBN.TabIndex = 18;
            this.rdb_NamBN.TabStop = true;
            this.rdb_NamBN.Text = "Nam";
            this.rdb_NamBN.UseVisualStyleBackColor = true;
            // 
            // rdb_NuBN
            // 
            this.rdb_NuBN.AutoSize = true;
            this.rdb_NuBN.Enabled = false;
            this.rdb_NuBN.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rdb_NuBN.Location = new System.Drawing.Point(293, 90);
            this.rdb_NuBN.Name = "rdb_NuBN";
            this.rdb_NuBN.Size = new System.Drawing.Size(40, 17);
            this.rdb_NuBN.TabIndex = 19;
            this.rdb_NuBN.TabStop = true;
            this.rdb_NuBN.Text = "Nữ";
            this.rdb_NuBN.UseVisualStyleBackColor = true;
            // 
            // det_NgaySinhBN
            // 
            this.det_NgaySinhBN.EditValue = null;
            this.det_NgaySinhBN.Location = new System.Drawing.Point(237, 124);
            this.det_NgaySinhBN.MenuManager = this.ribbon;
            this.det_NgaySinhBN.Name = "det_NgaySinhBN";
            this.det_NgaySinhBN.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.det_NgaySinhBN.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.det_NgaySinhBN.Properties.ReadOnly = true;
            this.det_NgaySinhBN.Size = new System.Drawing.Size(190, 20);
            this.det_NgaySinhBN.TabIndex = 20;
            // 
            // btn_HuyBN
            // 
            this.btn_HuyBN.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_HuyBN.Appearance.Options.UseFont = true;
            this.btn_HuyBN.Enabled = false;
            this.btn_HuyBN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HuyBN.ImageOptions.Image")));
            this.btn_HuyBN.Location = new System.Drawing.Point(820, 196);
            this.btn_HuyBN.Name = "btn_HuyBN";
            this.btn_HuyBN.Size = new System.Drawing.Size(112, 32);
            this.btn_HuyBN.TabIndex = 23;
            this.btn_HuyBN.Text = "Hủy";
            this.btn_HuyBN.Click += new System.EventHandler(this.btn_HuyBN_Click);
            // 
            // btn_LuuBN
            // 
            this.btn_LuuBN.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LuuBN.Appearance.Options.UseFont = true;
            this.btn_LuuBN.Enabled = false;
            this.btn_LuuBN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LuuBN.ImageOptions.Image")));
            this.btn_LuuBN.Location = new System.Drawing.Point(526, 196);
            this.btn_LuuBN.Name = "btn_LuuBN";
            this.btn_LuuBN.Size = new System.Drawing.Size(112, 32);
            this.btn_LuuBN.TabIndex = 24;
            this.btn_LuuBN.Text = "Lưu lại";
            this.btn_LuuBN.Click += new System.EventHandler(this.btn_LuuBN_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(162, 162);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "Nơi Sinh:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_NoiSinhBN
            // 
            this.txt_NoiSinhBN.Location = new System.Drawing.Point(237, 159);
            this.txt_NoiSinhBN.MenuManager = this.ribbon;
            this.txt_NoiSinhBN.Name = "txt_NoiSinhBN";
            this.txt_NoiSinhBN.Properties.ReadOnly = true;
            this.txt_NoiSinhBN.Size = new System.Drawing.Size(190, 20);
            this.txt_NoiSinhBN.TabIndex = 27;
            // 
            // btn_LoadBN
            // 
            this.btn_LoadBN.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LoadBN.Appearance.Options.UseFont = true;
            this.btn_LoadBN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LoadBN.ImageOptions.Image")));
            this.btn_LoadBN.Location = new System.Drawing.Point(675, 196);
            this.btn_LoadBN.Name = "btn_LoadBN";
            this.btn_LoadBN.Size = new System.Drawing.Size(109, 31);
            this.btn_LoadBN.TabIndex = 28;
            this.btn_LoadBN.Text = "Tải lại";
            this.btn_LoadBN.Click += new System.EventHandler(this.btn_LoadBN_Click);
            // 
            // grd_BenhNhan
            // 
            this.grd_BenhNhan.Location = new System.Drawing.Point(0, 358);
            this.grd_BenhNhan.MainView = this.gridViewBenhNhan;
            this.grd_BenhNhan.MenuManager = this.ribbon;
            this.grd_BenhNhan.Name = "grd_BenhNhan";
            this.grd_BenhNhan.Size = new System.Drawing.Size(1186, 200);
            this.grd_BenhNhan.TabIndex = 3;
            this.grd_BenhNhan.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewBenhNhan});
            // 
            // gridView6
            // 
            this.gridView6.GridControl = this.grd_BenhNhan;
            this.gridView6.Name = "gridView6";
            // 
            // gridViewBenhNhan
            // 
            this.gridViewBenhNhan.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.MaBN,
            this.HoTenBN,
            this.GioiTinhBN,
            this.DiaChiBN,
            this.NgaySinhBN,
            this.NoiSinhBN,
            this.CMNDBN,
            this.sdtBN,
            this.NgheNghiepBN,
            this.EmailBN});
            this.gridViewBenhNhan.GridControl = this.grd_BenhNhan;
            this.gridViewBenhNhan.Name = "gridViewBenhNhan";
            this.gridViewBenhNhan.OptionsBehavior.Editable = false;
            this.gridViewBenhNhan.OptionsBehavior.ReadOnly = true;
            this.gridViewBenhNhan.OptionsView.ShowGroupPanel = false;
            this.gridViewBenhNhan.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.gridViewBenhNhan_RowCellClick);
            this.gridViewBenhNhan.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewBenhNhan_FocusedRowChanged);
            // 
            // MaBN
            // 
            this.MaBN.Caption = "Mã Bệnh Nhân";
            this.MaBN.FieldName = "MaSoBenhNhan";
            this.MaBN.Name = "MaBN";
            this.MaBN.Visible = true;
            this.MaBN.VisibleIndex = 0;
            // 
            // HoTenBN
            // 
            this.HoTenBN.Caption = "Họ Tên";
            this.HoTenBN.FieldName = "HoTen";
            this.HoTenBN.Name = "HoTenBN";
            this.HoTenBN.Visible = true;
            this.HoTenBN.VisibleIndex = 1;
            // 
            // GioiTinhBN
            // 
            this.GioiTinhBN.Caption = "Giới Tính";
            this.GioiTinhBN.FieldName = "GioiTinh";
            this.GioiTinhBN.Name = "GioiTinhBN";
            this.GioiTinhBN.Visible = true;
            this.GioiTinhBN.VisibleIndex = 2;
            // 
            // DiaChiBN
            // 
            this.DiaChiBN.Caption = "Địa Chỉ";
            this.DiaChiBN.FieldName = "DiaChi";
            this.DiaChiBN.Name = "DiaChiBN";
            this.DiaChiBN.Visible = true;
            this.DiaChiBN.VisibleIndex = 3;
            // 
            // NgaySinhBN
            // 
            this.NgaySinhBN.Caption = "Ngày Sinh";
            this.NgaySinhBN.FieldName = "NgaySinh";
            this.NgaySinhBN.Name = "NgaySinhBN";
            this.NgaySinhBN.Visible = true;
            this.NgaySinhBN.VisibleIndex = 4;
            // 
            // NoiSinhBN
            // 
            this.NoiSinhBN.Caption = "Nơi Sinh";
            this.NoiSinhBN.FieldName = "NoiSinh";
            this.NoiSinhBN.Name = "NoiSinhBN";
            this.NoiSinhBN.Visible = true;
            this.NoiSinhBN.VisibleIndex = 5;
            // 
            // CMNDBN
            // 
            this.CMNDBN.Caption = "CMND";
            this.CMNDBN.FieldName = "CMND";
            this.CMNDBN.Name = "CMNDBN";
            this.CMNDBN.Visible = true;
            this.CMNDBN.VisibleIndex = 6;
            // 
            // sdtBN
            // 
            this.sdtBN.Caption = "Số Điện Thoại";
            this.sdtBN.FieldName = "SoDienThoai";
            this.sdtBN.Name = "sdtBN";
            this.sdtBN.Visible = true;
            this.sdtBN.VisibleIndex = 7;
            // 
            // NgheNghiepBN
            // 
            this.NgheNghiepBN.Caption = "Nghề Nghiệp";
            this.NgheNghiepBN.FieldName = "NgheNghiep";
            this.NgheNghiepBN.Name = "NgheNghiepBN";
            this.NgheNghiepBN.Visible = true;
            this.NgheNghiepBN.VisibleIndex = 8;
            // 
            // EmailBN
            // 
            this.EmailBN.Caption = "Email";
            this.EmailBN.FieldName = "Email";
            this.EmailBN.Name = "EmailBN";
            this.EmailBN.Visible = true;
            this.EmailBN.VisibleIndex = 9;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_HuySearchBN);
            this.groupBox4.Controls.Add(this.txt_SearchTenBN);
            this.groupBox4.Controls.Add(this.txt_SearchMaBN);
            this.groupBox4.Controls.Add(this.rdb_TenBN);
            this.groupBox4.Controls.Add(this.rdb_MaBN);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(0, 257);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1185, 95);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tìm Kiếm";
            // 
            // rdb_MaBN
            // 
            this.rdb_MaBN.AutoSize = true;
            this.rdb_MaBN.Location = new System.Drawing.Point(355, 23);
            this.rdb_MaBN.Name = "rdb_MaBN";
            this.rdb_MaBN.Size = new System.Drawing.Size(135, 17);
            this.rdb_MaBN.TabIndex = 25;
            this.rdb_MaBN.TabStop = true;
            this.rdb_MaBN.Text = "Theo Mã Bệnh Nhân";
            this.rdb_MaBN.UseVisualStyleBackColor = true;
            this.rdb_MaBN.CheckedChanged += new System.EventHandler(this.rdb_MaBN_CheckedChanged);
            // 
            // rdb_TenBN
            // 
            this.rdb_TenBN.AutoSize = true;
            this.rdb_TenBN.Location = new System.Drawing.Point(355, 66);
            this.rdb_TenBN.Name = "rdb_TenBN";
            this.rdb_TenBN.Size = new System.Drawing.Size(139, 17);
            this.rdb_TenBN.TabIndex = 26;
            this.rdb_TenBN.TabStop = true;
            this.rdb_TenBN.Text = "Theo Tên Bệnh Nhân";
            this.rdb_TenBN.UseVisualStyleBackColor = true;
            this.rdb_TenBN.CheckedChanged += new System.EventHandler(this.rdb_TenBN_CheckedChanged);
            // 
            // txt_SearchMaBN
            // 
            this.txt_SearchMaBN.Location = new System.Drawing.Point(516, 22);
            this.txt_SearchMaBN.MenuManager = this.ribbon;
            this.txt_SearchMaBN.Name = "txt_SearchMaBN";
            this.txt_SearchMaBN.Size = new System.Drawing.Size(190, 20);
            this.txt_SearchMaBN.TabIndex = 27;
            this.txt_SearchMaBN.TextChanged += new System.EventHandler(this.txt_SearchMaBN_TextChanged);
            // 
            // txt_SearchTenBN
            // 
            this.txt_SearchTenBN.Location = new System.Drawing.Point(516, 65);
            this.txt_SearchTenBN.MenuManager = this.ribbon;
            this.txt_SearchTenBN.Name = "txt_SearchTenBN";
            this.txt_SearchTenBN.Size = new System.Drawing.Size(190, 20);
            this.txt_SearchTenBN.TabIndex = 28;
            this.txt_SearchTenBN.TextChanged += new System.EventHandler(this.txt_SearchTenBN_TextChanged);
            // 
            // btn_HuySearchBN
            // 
            this.btn_HuySearchBN.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_HuySearchBN.Appearance.Options.UseFont = true;
            this.btn_HuySearchBN.Enabled = false;
            this.btn_HuySearchBN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HuySearchBN.ImageOptions.Image")));
            this.btn_HuySearchBN.Location = new System.Drawing.Point(743, 37);
            this.btn_HuySearchBN.Name = "btn_HuySearchBN";
            this.btn_HuySearchBN.Size = new System.Drawing.Size(101, 32);
            this.btn_HuySearchBN.TabIndex = 29;
            this.btn_HuySearchBN.Text = "Hủy";
            this.btn_HuySearchBN.Click += new System.EventHandler(this.btn_HuySearchBN_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btn_ThemBN);
            this.groupBox9.Controls.Add(this.btn_SuaBN);
            this.groupBox9.Controls.Add(this.btn_XoaBN);
            this.groupBox9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox9.Location = new System.Drawing.Point(0, 0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(185, 251);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Chức Năng";
            // 
            // btn_XoaBN
            // 
            this.btn_XoaBN.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_XoaBN.Appearance.Options.UseFont = true;
            this.btn_XoaBN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_XoaBN.ImageOptions.Image")));
            this.btn_XoaBN.Location = new System.Drawing.Point(6, 163);
            this.btn_XoaBN.Name = "btn_XoaBN";
            this.btn_XoaBN.Size = new System.Drawing.Size(173, 65);
            this.btn_XoaBN.TabIndex = 22;
            this.btn_XoaBN.Text = "Bệnh Nhân Xuất Viện";
            this.btn_XoaBN.Click += new System.EventHandler(this.btn_XoaBN_Click);
            // 
            // btn_SuaBN
            // 
            this.btn_SuaBN.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_SuaBN.Appearance.Options.UseFont = true;
            this.btn_SuaBN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_SuaBN.ImageOptions.Image")));
            this.btn_SuaBN.Location = new System.Drawing.Point(6, 101);
            this.btn_SuaBN.Name = "btn_SuaBN";
            this.btn_SuaBN.Size = new System.Drawing.Size(173, 65);
            this.btn_SuaBN.TabIndex = 25;
            this.btn_SuaBN.Text = "Sửa Thông Tin\r\n Bệnh Nhân";
            this.btn_SuaBN.Click += new System.EventHandler(this.btn_SuaBN_Click);
            // 
            // btn_ThemBN
            // 
            this.btn_ThemBN.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_ThemBN.Appearance.Options.UseFont = true;
            this.btn_ThemBN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_ThemBN.ImageOptions.Image")));
            this.btn_ThemBN.Location = new System.Drawing.Point(6, 38);
            this.btn_ThemBN.Name = "btn_ThemBN";
            this.btn_ThemBN.Size = new System.Drawing.Size(173, 63);
            this.btn_ThemBN.TabIndex = 21;
            this.btn_ThemBN.Text = "Thêm Thông Tin\r\n Bệnh Nhân Nhập Viện\r\n";
            this.btn_ThemBN.Click += new System.EventHandler(this.btn_ThemBN_Click);
            // 
            // Tab_BacSy
            // 
            this.Tab_BacSy.Controls.Add(this.groupBox8);
            this.Tab_BacSy.Controls.Add(this.groupBox2);
            this.Tab_BacSy.Controls.Add(this.grd_BacSy);
            this.Tab_BacSy.Controls.Add(this.groupBox1);
            this.Tab_BacSy.Image = ((System.Drawing.Image)(resources.GetObject("Tab_BacSy.Image")));
            this.Tab_BacSy.Name = "Tab_BacSy";
            this.Tab_BacSy.PageVisible = false;
            this.Tab_BacSy.Size = new System.Drawing.Size(1181, 558);
            this.Tab_BacSy.Text = "Bác Sỹ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_LoadBS);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.btn_LuuBS);
            this.groupBox1.Controls.Add(this.btn_HuyBS);
            this.groupBox1.Controls.Add(this.det_NgaySinh);
            this.groupBox1.Controls.Add(this.rdb_Nu);
            this.groupBox1.Controls.Add(this.rdb_Nam);
            this.groupBox1.Controls.Add(this.txt_MaKhoa);
            this.groupBox1.Controls.Add(this.txt_HoTen);
            this.groupBox1.Controls.Add(this.txt_CMND);
            this.groupBox1.Controls.Add(this.txt_DiaChi);
            this.groupBox1.Controls.Add(this.txt_SoDienThoai);
            this.groupBox1.Controls.Add(this.txt_TrinhDoCM);
            this.groupBox1.Controls.Add(this.txt_Email);
            this.groupBox1.Controls.Add(this.txt_MaBacSy);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(184, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1002, 251);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quản Lý Bác Sỹ ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(120, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Bác Sỹ:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(138, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Họ Tên:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(601, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "CMND:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(513, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Trình Độ Chuyên Môn:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(594, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Địa Chỉ:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(601, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Email:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(556, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Số Điện Thoại:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(129, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Giới Tính:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(129, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Mã Khoa:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_MaBacSy
            // 
            this.txt_MaBacSy.Location = new System.Drawing.Point(208, 30);
            this.txt_MaBacSy.MenuManager = this.ribbon;
            this.txt_MaBacSy.Name = "txt_MaBacSy";
            this.txt_MaBacSy.Properties.ReadOnly = true;
            this.txt_MaBacSy.Size = new System.Drawing.Size(190, 20);
            this.txt_MaBacSy.TabIndex = 10;
            // 
            // txt_Email
            // 
            this.txt_Email.Location = new System.Drawing.Point(668, 135);
            this.txt_Email.MenuManager = this.ribbon;
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Properties.ReadOnly = true;
            this.txt_Email.Size = new System.Drawing.Size(269, 20);
            this.txt_Email.TabIndex = 11;
            // 
            // txt_TrinhDoCM
            // 
            this.txt_TrinhDoCM.Location = new System.Drawing.Point(668, 169);
            this.txt_TrinhDoCM.MenuManager = this.ribbon;
            this.txt_TrinhDoCM.Name = "txt_TrinhDoCM";
            this.txt_TrinhDoCM.Properties.ReadOnly = true;
            this.txt_TrinhDoCM.Size = new System.Drawing.Size(269, 20);
            this.txt_TrinhDoCM.TabIndex = 12;
            // 
            // txt_SoDienThoai
            // 
            this.txt_SoDienThoai.Location = new System.Drawing.Point(668, 98);
            this.txt_SoDienThoai.MenuManager = this.ribbon;
            this.txt_SoDienThoai.Name = "txt_SoDienThoai";
            this.txt_SoDienThoai.Properties.ReadOnly = true;
            this.txt_SoDienThoai.Size = new System.Drawing.Size(269, 20);
            this.txt_SoDienThoai.TabIndex = 13;
            // 
            // txt_DiaChi
            // 
            this.txt_DiaChi.Location = new System.Drawing.Point(668, 62);
            this.txt_DiaChi.MenuManager = this.ribbon;
            this.txt_DiaChi.Name = "txt_DiaChi";
            this.txt_DiaChi.Properties.ReadOnly = true;
            this.txt_DiaChi.Size = new System.Drawing.Size(269, 20);
            this.txt_DiaChi.TabIndex = 14;
            // 
            // txt_CMND
            // 
            this.txt_CMND.Location = new System.Drawing.Point(668, 30);
            this.txt_CMND.MenuManager = this.ribbon;
            this.txt_CMND.Name = "txt_CMND";
            this.txt_CMND.Properties.ReadOnly = true;
            this.txt_CMND.Size = new System.Drawing.Size(269, 20);
            this.txt_CMND.TabIndex = 15;
            // 
            // txt_HoTen
            // 
            this.txt_HoTen.Location = new System.Drawing.Point(208, 98);
            this.txt_HoTen.MenuManager = this.ribbon;
            this.txt_HoTen.Name = "txt_HoTen";
            this.txt_HoTen.Properties.ReadOnly = true;
            this.txt_HoTen.Size = new System.Drawing.Size(190, 20);
            this.txt_HoTen.TabIndex = 16;
            // 
            // txt_MaKhoa
            // 
            this.txt_MaKhoa.Location = new System.Drawing.Point(208, 62);
            this.txt_MaKhoa.MenuManager = this.ribbon;
            this.txt_MaKhoa.Name = "txt_MaKhoa";
            this.txt_MaKhoa.Properties.ReadOnly = true;
            this.txt_MaKhoa.Size = new System.Drawing.Size(190, 20);
            this.txt_MaKhoa.TabIndex = 17;
            // 
            // rdb_Nam
            // 
            this.rdb_Nam.AutoSize = true;
            this.rdb_Nam.Enabled = false;
            this.rdb_Nam.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rdb_Nam.Location = new System.Drawing.Point(208, 136);
            this.rdb_Nam.Name = "rdb_Nam";
            this.rdb_Nam.Size = new System.Drawing.Size(50, 17);
            this.rdb_Nam.TabIndex = 18;
            this.rdb_Nam.TabStop = true;
            this.rdb_Nam.Text = "Nam";
            this.rdb_Nam.UseVisualStyleBackColor = true;
            // 
            // rdb_Nu
            // 
            this.rdb_Nu.AutoSize = true;
            this.rdb_Nu.Enabled = false;
            this.rdb_Nu.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rdb_Nu.Location = new System.Drawing.Point(273, 136);
            this.rdb_Nu.Name = "rdb_Nu";
            this.rdb_Nu.Size = new System.Drawing.Size(40, 17);
            this.rdb_Nu.TabIndex = 19;
            this.rdb_Nu.TabStop = true;
            this.rdb_Nu.Text = "Nữ";
            this.rdb_Nu.UseVisualStyleBackColor = true;
            // 
            // det_NgaySinh
            // 
            this.det_NgaySinh.EditValue = null;
            this.det_NgaySinh.Location = new System.Drawing.Point(208, 169);
            this.det_NgaySinh.MenuManager = this.ribbon;
            this.det_NgaySinh.Name = "det_NgaySinh";
            this.det_NgaySinh.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.det_NgaySinh.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.det_NgaySinh.Properties.ReadOnly = true;
            this.det_NgaySinh.Size = new System.Drawing.Size(190, 20);
            this.det_NgaySinh.TabIndex = 20;
            // 
            // btn_HuyBS
            // 
            this.btn_HuyBS.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_HuyBS.Appearance.Options.UseFont = true;
            this.btn_HuyBS.Enabled = false;
            this.btn_HuyBS.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HuyBS.ImageOptions.Image")));
            this.btn_HuyBS.Location = new System.Drawing.Point(830, 204);
            this.btn_HuyBS.Name = "btn_HuyBS";
            this.btn_HuyBS.Size = new System.Drawing.Size(107, 32);
            this.btn_HuyBS.TabIndex = 23;
            this.btn_HuyBS.Text = "Hủy";
            this.btn_HuyBS.Click += new System.EventHandler(this.btn_HuyBS_Click);
            // 
            // btn_LuuBS
            // 
            this.btn_LuuBS.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LuuBS.Appearance.Options.UseFont = true;
            this.btn_LuuBS.Enabled = false;
            this.btn_LuuBS.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LuuBS.ImageOptions.Image")));
            this.btn_LuuBS.Location = new System.Drawing.Point(543, 203);
            this.btn_LuuBS.Name = "btn_LuuBS";
            this.btn_LuuBS.Size = new System.Drawing.Size(106, 32);
            this.btn_LuuBS.TabIndex = 24;
            this.btn_LuuBS.Text = "Lưu lại";
            this.btn_LuuBS.Click += new System.EventHandler(this.btn_LuuBS_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(122, 169);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 13);
            this.label21.TabIndex = 26;
            this.label21.Text = "Ngày Sinh:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_LoadBS
            // 
            this.btn_LoadBS.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_LoadBS.Appearance.Options.UseFont = true;
            this.btn_LoadBS.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LoadBS.ImageOptions.Image")));
            this.btn_LoadBS.Location = new System.Drawing.Point(681, 204);
            this.btn_LoadBS.Name = "btn_LoadBS";
            this.btn_LoadBS.Size = new System.Drawing.Size(109, 31);
            this.btn_LoadBS.TabIndex = 29;
            this.btn_LoadBS.Text = "Tải lại";
            this.btn_LoadBS.Click += new System.EventHandler(this.btn_LoadBS_Click);
            // 
            // grd_BacSy
            // 
            this.grd_BacSy.Location = new System.Drawing.Point(0, 357);
            this.grd_BacSy.MainView = this.gridViewBacSy;
            this.grd_BacSy.MenuManager = this.ribbon;
            this.grd_BacSy.Name = "grd_BacSy";
            this.grd_BacSy.Size = new System.Drawing.Size(1186, 201);
            this.grd_BacSy.TabIndex = 2;
            this.grd_BacSy.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewBacSy});
            // 
            // gridView7
            // 
            this.gridView7.GridControl = this.grd_BacSy;
            this.gridView7.Name = "gridView7";
            // 
            // gridViewBacSy
            // 
            this.gridViewBacSy.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.MaBS,
            this.MaKhoa,
            this.HoTen,
            this.GioiTinh,
            this.NgaySinh,
            this.CMND,
            this.DiaChi,
            this.SoDienThoai,
            this.Email,
            this.TrinhDoChuyenMon});
            this.gridViewBacSy.GridControl = this.grd_BacSy;
            this.gridViewBacSy.Name = "gridViewBacSy";
            this.gridViewBacSy.OptionsBehavior.Editable = false;
            this.gridViewBacSy.OptionsBehavior.ReadOnly = true;
            this.gridViewBacSy.OptionsView.ShowGroupPanel = false;
            this.gridViewBacSy.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.gridViewBacSy_RowCellClick);
            this.gridViewBacSy.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewBacSy_FocusedRowChanged);
            this.gridViewBacSy.MouseEnter += new System.EventHandler(this.gridViewBacSy_MouseEnter);
            // 
            // MaBS
            // 
            this.MaBS.Caption = "Mã Bác Sỹ ";
            this.MaBS.FieldName = "MaBacSy";
            this.MaBS.Name = "MaBS";
            this.MaBS.Visible = true;
            this.MaBS.VisibleIndex = 0;
            // 
            // MaKhoa
            // 
            this.MaKhoa.Caption = "Mã Khoa";
            this.MaKhoa.FieldName = "MaKhoa";
            this.MaKhoa.Name = "MaKhoa";
            this.MaKhoa.Visible = true;
            this.MaKhoa.VisibleIndex = 1;
            // 
            // HoTen
            // 
            this.HoTen.Caption = "Họ Tên";
            this.HoTen.FieldName = "HoTen";
            this.HoTen.Name = "HoTen";
            this.HoTen.Visible = true;
            this.HoTen.VisibleIndex = 2;
            // 
            // GioiTinh
            // 
            this.GioiTinh.Caption = "Giới Tính";
            this.GioiTinh.FieldName = "GioiTinh";
            this.GioiTinh.Name = "GioiTinh";
            this.GioiTinh.Visible = true;
            this.GioiTinh.VisibleIndex = 3;
            // 
            // NgaySinh
            // 
            this.NgaySinh.Caption = "Ngày Sinh";
            this.NgaySinh.FieldName = "NgaySinh";
            this.NgaySinh.Name = "NgaySinh";
            this.NgaySinh.Visible = true;
            this.NgaySinh.VisibleIndex = 4;
            // 
            // CMND
            // 
            this.CMND.Caption = "CMND";
            this.CMND.FieldName = "CMND";
            this.CMND.Name = "CMND";
            this.CMND.Visible = true;
            this.CMND.VisibleIndex = 5;
            // 
            // DiaChi
            // 
            this.DiaChi.Caption = "Địa Chỉ";
            this.DiaChi.FieldName = "DiaChi";
            this.DiaChi.Name = "DiaChi";
            this.DiaChi.Visible = true;
            this.DiaChi.VisibleIndex = 6;
            // 
            // SoDienThoai
            // 
            this.SoDienThoai.Caption = "Số Điện Thoại";
            this.SoDienThoai.FieldName = "SoDienThoai";
            this.SoDienThoai.Name = "SoDienThoai";
            this.SoDienThoai.Visible = true;
            this.SoDienThoai.VisibleIndex = 7;
            // 
            // Email
            // 
            this.Email.Caption = "Email";
            this.Email.FieldName = "Email";
            this.Email.Name = "Email";
            this.Email.Visible = true;
            this.Email.VisibleIndex = 8;
            // 
            // TrinhDoChuyenMon
            // 
            this.TrinhDoChuyenMon.Caption = "Trình Độ Chuyên Môn";
            this.TrinhDoChuyenMon.FieldName = "TrinhDoChuyenMon";
            this.TrinhDoChuyenMon.Name = "TrinhDoChuyenMon";
            this.TrinhDoChuyenMon.Visible = true;
            this.TrinhDoChuyenMon.VisibleIndex = 9;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_HuySearchBS);
            this.groupBox2.Controls.Add(this.txt_SearchTenBS);
            this.groupBox2.Controls.Add(this.txt_SearchMaBS);
            this.groupBox2.Controls.Add(this.rdb_TenBS);
            this.groupBox2.Controls.Add(this.rdb_MaBS);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(0, 255);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1186, 96);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm Kiếm";
            // 
            // rdb_MaBS
            // 
            this.rdb_MaBS.AutoSize = true;
            this.rdb_MaBS.Location = new System.Drawing.Point(364, 23);
            this.rdb_MaBS.Name = "rdb_MaBS";
            this.rdb_MaBS.Size = new System.Drawing.Size(113, 17);
            this.rdb_MaBS.TabIndex = 25;
            this.rdb_MaBS.TabStop = true;
            this.rdb_MaBS.Text = "Theo Mã Bác Sỹ";
            this.rdb_MaBS.UseVisualStyleBackColor = true;
            this.rdb_MaBS.CheckedChanged += new System.EventHandler(this.rdb_MaBS_CheckedChanged);
            // 
            // rdb_TenBS
            // 
            this.rdb_TenBS.AutoSize = true;
            this.rdb_TenBS.Location = new System.Drawing.Point(364, 66);
            this.rdb_TenBS.Name = "rdb_TenBS";
            this.rdb_TenBS.Size = new System.Drawing.Size(117, 17);
            this.rdb_TenBS.TabIndex = 26;
            this.rdb_TenBS.TabStop = true;
            this.rdb_TenBS.Text = "Theo Tên Bác Sỹ";
            this.rdb_TenBS.UseVisualStyleBackColor = true;
            this.rdb_TenBS.CheckedChanged += new System.EventHandler(this.rdb_TenBS_CheckedChanged);
            // 
            // txt_SearchMaBS
            // 
            this.txt_SearchMaBS.Location = new System.Drawing.Point(507, 22);
            this.txt_SearchMaBS.MenuManager = this.ribbon;
            this.txt_SearchMaBS.Name = "txt_SearchMaBS";
            this.txt_SearchMaBS.Size = new System.Drawing.Size(190, 20);
            this.txt_SearchMaBS.TabIndex = 27;
            this.txt_SearchMaBS.TextChanged += new System.EventHandler(this.txt_SearchMaBS_TextChanged);
            // 
            // txt_SearchTenBS
            // 
            this.txt_SearchTenBS.Location = new System.Drawing.Point(507, 65);
            this.txt_SearchTenBS.MenuManager = this.ribbon;
            this.txt_SearchTenBS.Name = "txt_SearchTenBS";
            this.txt_SearchTenBS.Size = new System.Drawing.Size(190, 20);
            this.txt_SearchTenBS.TabIndex = 28;
            this.txt_SearchTenBS.TextChanged += new System.EventHandler(this.txt_SearchTenBS_TextChanged);
            // 
            // btn_HuySearchBS
            // 
            this.btn_HuySearchBS.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_HuySearchBS.Appearance.Options.UseFont = true;
            this.btn_HuySearchBS.Enabled = false;
            this.btn_HuySearchBS.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HuySearchBS.ImageOptions.Image")));
            this.btn_HuySearchBS.Location = new System.Drawing.Point(734, 37);
            this.btn_HuySearchBS.Name = "btn_HuySearchBS";
            this.btn_HuySearchBS.Size = new System.Drawing.Size(98, 32);
            this.btn_HuySearchBS.TabIndex = 29;
            this.btn_HuySearchBS.Text = "Hủy";
            this.btn_HuySearchBS.Click += new System.EventHandler(this.btn_HuySearchBS_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btn_ThemBS);
            this.groupBox8.Controls.Add(this.btn_SuaBS);
            this.groupBox8.Controls.Add(this.btn_XoaBS);
            this.groupBox8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox8.Location = new System.Drawing.Point(0, 0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(185, 251);
            this.groupBox8.TabIndex = 4;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Chức Năng";
            // 
            // btn_XoaBS
            // 
            this.btn_XoaBS.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_XoaBS.Appearance.Options.UseFont = true;
            this.btn_XoaBS.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_XoaBS.ImageOptions.Image")));
            this.btn_XoaBS.Location = new System.Drawing.Point(5, 160);
            this.btn_XoaBS.Name = "btn_XoaBS";
            this.btn_XoaBS.Size = new System.Drawing.Size(173, 64);
            this.btn_XoaBS.TabIndex = 22;
            this.btn_XoaBS.Text = "Xóa Thông Tin Bác Sỹ";
            this.btn_XoaBS.Click += new System.EventHandler(this.btn_XoaBS_Click);
            // 
            // btn_SuaBS
            // 
            this.btn_SuaBS.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_SuaBS.Appearance.Options.UseFont = true;
            this.btn_SuaBS.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_SuaBS.ImageOptions.Image")));
            this.btn_SuaBS.Location = new System.Drawing.Point(5, 98);
            this.btn_SuaBS.Name = "btn_SuaBS";
            this.btn_SuaBS.Size = new System.Drawing.Size(173, 64);
            this.btn_SuaBS.TabIndex = 25;
            this.btn_SuaBS.Text = "Sửa Thông Tin Bác Sỹ";
            this.btn_SuaBS.Click += new System.EventHandler(this.btn_SuaBS_Click);
            // 
            // btn_ThemBS
            // 
            this.btn_ThemBS.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_ThemBS.Appearance.Options.UseFont = true;
            this.btn_ThemBS.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_ThemBS.ImageOptions.Image")));
            this.btn_ThemBS.Location = new System.Drawing.Point(5, 33);
            this.btn_ThemBS.Name = "btn_ThemBS";
            this.btn_ThemBS.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_ThemBS.Size = new System.Drawing.Size(173, 67);
            this.btn_ThemBS.TabIndex = 21;
            this.btn_ThemBS.Text = "Thêm Thông Tin Bác Sỹ";
            this.btn_ThemBS.Click += new System.EventHandler(this.btn_ThemBS_Click);
            // 
            // Tab_GioiThieu
            // 
            this.Tab_GioiThieu.Controls.Add(this.pictureBox1);
            this.Tab_GioiThieu.Image = ((System.Drawing.Image)(resources.GetObject("Tab_GioiThieu.Image")));
            this.Tab_GioiThieu.Name = "Tab_GioiThieu";
            this.Tab_GioiThieu.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.Tab_GioiThieu.Size = new System.Drawing.Size(1181, 558);
            this.Tab_GioiThieu.Text = "Bệnh Viện";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1181, 558);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Tab_Main
            // 
            this.Tab_Main.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InAllTabPageHeaders;
            this.Tab_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tab_Main.Location = new System.Drawing.Point(0, 143);
            this.Tab_Main.Name = "Tab_Main";
            this.Tab_Main.SelectedTabPage = this.Tab_GioiThieu;
            this.Tab_Main.Size = new System.Drawing.Size(1187, 597);
            this.Tab_Main.TabIndex = 9;
            this.Tab_Main.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.Tab_GioiThieu,
            this.Tab_BacSy,
            this.Tab_BenhNhan,
            this.Tab_GiuongBenh,
            this.Tab_PhongBenh,
            this.Tab_PhanCong,
            this.Tab_SapXepBenhNhan});
            this.Tab_Main.CloseButtonClick += new System.EventHandler(this.Tab_Main_CloseButtonClick);
            // 
            // Main
            // 
            this.AllowFormGlass = DevExpress.Utils.DefaultBoolean.False;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1187, 740);
            this.Controls.Add(this.Tab_Main);
            this.Controls.Add(this.ribbon);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main";
            this.Ribbon = this.ribbon;
            this.Text = "Quản Lý Giường Bệnh Viện";
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.Tab_SapXepBenhNhan.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MGBSapXep.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MSBNSapXep.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimeNV.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimeNV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimeXV.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimeXV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_SXBN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSXBN)).EndInit();
            this.Tab_PhanCong.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DiUngThuoc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NhomMau.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TinhTrangBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaBacSyPC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaBenhNhanPC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TienSuBA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimePC.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_TimePC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_PhanCong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPhanCong)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.Tab_PhongBenh.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkE_PhongBenh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaPB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TenPhongBenh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SoGiuongBenh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_LoaiPhong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_PhongBenh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPhongBenh)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.Tab_GiuongBenh.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grd_GiuongBenh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGiuongBenh)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkE_NguoiNam.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaGiuongBenh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_LoaiGiuongBenh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaPhong.Properties)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.Tab_BenhNhan.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_EmailBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NgheNghiepBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SdtBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DiaChiBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_CMNDBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_HoTenBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.det_NgaySinhBN.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.det_NgaySinhBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NoiSinhBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_BenhNhan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewBenhNhan)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SearchMaBN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SearchTenBN.Properties)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.Tab_BacSy.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaBacSy.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Email.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TrinhDoCM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SoDienThoai.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_DiaChi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_CMND.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_HoTen.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MaKhoa.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.det_NgaySinh.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.det_NgaySinh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_BacSy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewBacSy)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SearchMaBS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SearchTenBS.Properties)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.Tab_GioiThieu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab_Main)).EndInit();
            this.Tab_Main.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbon;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem btnLogin;
        private DevExpress.XtraBars.BarButtonItem btnDoimatkhau;
        private DevExpress.XtraBars.BarButtonItem btnLogout;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraBars.BarButtonItem barButtonItem8;
        private DevExpress.XtraBars.BarButtonItem btnDocGia;
        private DevExpress.XtraBars.BarButtonItem btnSach;
        private DevExpress.XtraBars.BarButtonItem btnLoaiSach;
        private DevExpress.XtraBars.BarButtonItem btnNhaXuatBan;
        private DevExpress.XtraBars.BarButtonItem btnNhanVien;
        private DevExpress.XtraBars.BarButtonItem barButtonItem9;
        private DevExpress.XtraBars.BarButtonItem barButtonItem10;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem12;
        private DevExpress.XtraBars.BarButtonItem btnExit;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup8;
        private DevExpress.XtraBars.Ribbon.RibbonPage rbQLDanhMuc;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.Ribbon.RibbonPage rbMTSach;
        private DevExpress.XtraBars.BarButtonItem btn_BacSy;
        private DevExpress.XtraBars.BarButtonItem btn_BenhNhan;
        private DevExpress.XtraBars.BarButtonItem btn_GiuongBenh;
        private DevExpress.XtraBars.BarButtonItem btn_PhongBenh;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem btn_SapXepBN;
        private DevExpress.XtraBars.BarButtonItem btn_PhanCong;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.BarButtonItem barButtonItem11;
        private DevExpress.XtraBars.BarButtonItem btn_PC;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup7;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup9;
        private DevExpress.XtraBars.BarButtonItem btn_HoaDon;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraTab.XtraTabPage Tab_SapXepBenhNhan;
        private DevExpress.XtraGrid.GridControl grd_SXBN;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewSXBN;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn29;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label38;
        private DevExpress.XtraEditors.DateEdit date_TimeXV;
        private DevExpress.XtraEditors.DateEdit date_TimeNV;
        private DevExpress.XtraEditors.SimpleButton btn_LoadSX;
        private DevExpress.XtraEditors.TextEdit txt_MSBNSapXep;
        private DevExpress.XtraEditors.TextEdit txt_MGBSapXep;
        private System.Windows.Forms.Label label36;
        private DevExpress.XtraEditors.SimpleButton btn_LuuSX;
        private DevExpress.XtraEditors.SimpleButton btn_HuySX;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox13;
        private DevExpress.XtraEditors.SimpleButton btn_ThemSX;
        private DevExpress.XtraEditors.SimpleButton btn_SuaSX;
        private DevExpress.XtraEditors.SimpleButton btn_XoaSX;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraTab.XtraTabPage Tab_PhanCong;
        private System.Windows.Forms.GroupBox groupBox12;
        private DevExpress.XtraEditors.SimpleButton btn_ThemPC;
        private DevExpress.XtraEditors.SimpleButton btn_SuaPC;
        private DevExpress.XtraEditors.SimpleButton btn_XoaPC;
        private DevExpress.XtraGrid.GridControl grd_PhanCong;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewPhanCong;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private System.Windows.Forms.GroupBox groupBox7;
        private DevExpress.XtraEditors.DateEdit date_TimePC;
        private DevExpress.XtraEditors.TextEdit txt_TienSuBA;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private DevExpress.XtraEditors.SimpleButton btn_LoadPC;
        private DevExpress.XtraEditors.TextEdit txt_MaBenhNhanPC;
        private DevExpress.XtraEditors.TextEdit txt_MaBacSyPC;
        private DevExpress.XtraEditors.TextEdit txt_TinhTrangBN;
        private DevExpress.XtraEditors.TextEdit txt_NhomMau;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private DevExpress.XtraEditors.SimpleButton btn_LuuPC;
        private DevExpress.XtraEditors.SimpleButton btn_HuyPC;
        private DevExpress.XtraEditors.TextEdit txt_DiUngThuoc;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DevExpress.XtraTab.XtraTabPage Tab_PhongBenh;
        private System.Windows.Forms.GroupBox groupBox11;
        private DevExpress.XtraEditors.SimpleButton btn_ThemPB;
        private DevExpress.XtraEditors.SimpleButton btn_SuaPB;
        private DevExpress.XtraEditors.SimpleButton btn_XoaPB;
        private DevExpress.XtraGrid.GridControl grd_PhongBenh;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewPhongBenh;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private System.Windows.Forms.GroupBox groupBox6;
        private DevExpress.XtraEditors.SimpleButton btn_LoadPB;
        private DevExpress.XtraEditors.TextEdit txt_LoaiPhong;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label26;
        private DevExpress.XtraEditors.SimpleButton btn_LuuPB;
        private DevExpress.XtraEditors.SimpleButton btn_HuyPB;
        private DevExpress.XtraEditors.TextEdit txt_SoGiuongBenh;
        private DevExpress.XtraEditors.TextEdit txt_TenPhongBenh;
        private DevExpress.XtraEditors.TextEdit txt_MaPB;
        private DevExpress.XtraEditors.CheckEdit checkE_PhongBenh;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
        private DevExpress.XtraTab.XtraTabPage Tab_GiuongBenh;
        private System.Windows.Forms.GroupBox groupBox10;
        private DevExpress.XtraEditors.SimpleButton btn_ThemGB;
        private DevExpress.XtraEditors.SimpleButton btn_SuaGB;
        private DevExpress.XtraEditors.SimpleButton btn_XoaGB;
        private System.Windows.Forms.GroupBox groupBox5;
        private DevExpress.XtraEditors.TextEdit txt_MaPhong;
        private DevExpress.XtraEditors.SimpleButton btn_LoadGB;
        private System.Windows.Forms.Label label22;
        private DevExpress.XtraEditors.SimpleButton btn_LuuGB;
        private DevExpress.XtraEditors.SimpleButton btn_HuyGB;
        private DevExpress.XtraEditors.TextEdit txt_LoaiGiuongBenh;
        private DevExpress.XtraEditors.TextEdit txt_MaGiuongBenh;
        private DevExpress.XtraEditors.CheckEdit checkE_NguoiNam;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private DevExpress.XtraGrid.GridControl grd_GiuongBenh;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewGiuongBenh;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView5;
        private DevExpress.XtraTab.XtraTabPage Tab_BenhNhan;
        private System.Windows.Forms.GroupBox groupBox9;
        private DevExpress.XtraEditors.SimpleButton btn_ThemBN;
        private DevExpress.XtraEditors.SimpleButton btn_SuaBN;
        private DevExpress.XtraEditors.SimpleButton btn_XoaBN;
        private System.Windows.Forms.GroupBox groupBox4;
        private DevExpress.XtraEditors.SimpleButton btn_HuySearchBN;
        private DevExpress.XtraEditors.TextEdit txt_SearchTenBN;
        private DevExpress.XtraEditors.TextEdit txt_SearchMaBN;
        private System.Windows.Forms.RadioButton rdb_TenBN;
        private System.Windows.Forms.RadioButton rdb_MaBN;
        private DevExpress.XtraGrid.GridControl grd_BenhNhan;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewBenhNhan;
        private DevExpress.XtraGrid.Columns.GridColumn MaBN;
        private DevExpress.XtraGrid.Columns.GridColumn HoTenBN;
        private DevExpress.XtraGrid.Columns.GridColumn GioiTinhBN;
        private DevExpress.XtraGrid.Columns.GridColumn DiaChiBN;
        private DevExpress.XtraGrid.Columns.GridColumn NgaySinhBN;
        private DevExpress.XtraGrid.Columns.GridColumn NoiSinhBN;
        private DevExpress.XtraGrid.Columns.GridColumn CMNDBN;
        private DevExpress.XtraGrid.Columns.GridColumn sdtBN;
        private DevExpress.XtraGrid.Columns.GridColumn NgheNghiepBN;
        private DevExpress.XtraGrid.Columns.GridColumn EmailBN;
        private System.Windows.Forms.GroupBox groupBox3;
        private DevExpress.XtraEditors.SimpleButton btn_LoadBN;
        private DevExpress.XtraEditors.TextEdit txt_NoiSinhBN;
        private System.Windows.Forms.Label label10;
        private DevExpress.XtraEditors.SimpleButton btn_LuuBN;
        private DevExpress.XtraEditors.SimpleButton btn_HuyBN;
        private DevExpress.XtraEditors.DateEdit det_NgaySinhBN;
        private System.Windows.Forms.RadioButton rdb_NuBN;
        private System.Windows.Forms.RadioButton rdb_NamBN;
        private DevExpress.XtraEditors.TextEdit txt_HoTenBN;
        private DevExpress.XtraEditors.TextEdit txt_CMNDBN;
        private DevExpress.XtraEditors.TextEdit txt_DiaChiBN;
        private DevExpress.XtraEditors.TextEdit txt_SdtBN;
        private DevExpress.XtraEditors.TextEdit txt_NgheNghiepBN;
        private DevExpress.XtraEditors.TextEdit txt_EmailBN;
        private DevExpress.XtraEditors.TextEdit txt_MaBN;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView6;
        private DevExpress.XtraTab.XtraTabPage Tab_BacSy;
        private System.Windows.Forms.GroupBox groupBox8;
        private DevExpress.XtraEditors.SimpleButton btn_ThemBS;
        private DevExpress.XtraEditors.SimpleButton btn_SuaBS;
        private DevExpress.XtraEditors.SimpleButton btn_XoaBS;
        private System.Windows.Forms.GroupBox groupBox2;
        private DevExpress.XtraEditors.SimpleButton btn_HuySearchBS;
        private DevExpress.XtraEditors.TextEdit txt_SearchTenBS;
        private DevExpress.XtraEditors.TextEdit txt_SearchMaBS;
        private System.Windows.Forms.RadioButton rdb_TenBS;
        private System.Windows.Forms.RadioButton rdb_MaBS;
        private DevExpress.XtraGrid.GridControl grd_BacSy;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewBacSy;
        private DevExpress.XtraGrid.Columns.GridColumn MaBS;
        private DevExpress.XtraGrid.Columns.GridColumn MaKhoa;
        private DevExpress.XtraGrid.Columns.GridColumn HoTen;
        private DevExpress.XtraGrid.Columns.GridColumn GioiTinh;
        private DevExpress.XtraGrid.Columns.GridColumn NgaySinh;
        private DevExpress.XtraGrid.Columns.GridColumn CMND;
        private DevExpress.XtraGrid.Columns.GridColumn DiaChi;
        private DevExpress.XtraGrid.Columns.GridColumn SoDienThoai;
        private DevExpress.XtraGrid.Columns.GridColumn Email;
        private DevExpress.XtraGrid.Columns.GridColumn TrinhDoChuyenMon;
        private System.Windows.Forms.GroupBox groupBox1;
        private DevExpress.XtraEditors.SimpleButton btn_LoadBS;
        private System.Windows.Forms.Label label21;
        private DevExpress.XtraEditors.SimpleButton btn_LuuBS;
        private DevExpress.XtraEditors.SimpleButton btn_HuyBS;
        private DevExpress.XtraEditors.DateEdit det_NgaySinh;
        private System.Windows.Forms.RadioButton rdb_Nu;
        private System.Windows.Forms.RadioButton rdb_Nam;
        private DevExpress.XtraEditors.TextEdit txt_MaKhoa;
        private DevExpress.XtraEditors.TextEdit txt_HoTen;
        private DevExpress.XtraEditors.TextEdit txt_CMND;
        private DevExpress.XtraEditors.TextEdit txt_DiaChi;
        private DevExpress.XtraEditors.TextEdit txt_SoDienThoai;
        private DevExpress.XtraEditors.TextEdit txt_TrinhDoCM;
        private DevExpress.XtraEditors.TextEdit txt_Email;
        private DevExpress.XtraEditors.TextEdit txt_MaBacSy;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView7;
        private DevExpress.XtraTab.XtraTabPage Tab_GioiThieu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraTab.XtraTabControl Tab_Main;
    }
}

