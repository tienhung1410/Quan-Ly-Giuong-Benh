﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using QuanLyGiuongBenhVien.Models;

namespace QuanLyGiuongBenhVien.Views
{
    public partial class DoiMatKhau : DevExpress.XtraEditors.XtraForm
    {
        public DoiMatKhau()
        {
            InitializeComponent();
        }
        Connection cls_ketnoi = new Connection();

        private void btnLogin_Click(object sender, EventArgs e)
        {
            DataTable TbAd = SqlHelper.ExecuteDataset(Connection.sqlcon, "ADMIN_Select_TK", Login.user, txtPass1.Text).Tables[0];
            try
            {
                if (txtPass1.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mật Khẩu Hiện Tại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPass1.Focus();
                }
                else if (txtPass2.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mật Khẩu Mới!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPass2.Focus();
                }
                else if (txtPass3.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Lại Mật Khẩu Mới!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPass3.Focus();
                }
                else if (txtPass2.Text == txtPass3.Text && TbAd.Rows.Count > 0)
                {
                    MessageBox.Show("Thay Đổi Mật Khẩu Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "ADMIN_Update", Login.user, txtPass2.Text);
                    Close();
                }
                else
                {
                    MessageBox.Show("Đổi Mật Khẩu Thất Bại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPass1.Text = "";
                    txtPass2.Text = "";
                    txtPass3.Text = "";
                    txtPass1.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn Có Muốn Thoát?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }
    }
}