﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using QuanLyGiuongBenhVien.Views;
using Microsoft.ApplicationBlocks.Data;
using QuanLyGiuongBenhVien.Models;
using DevExpress.XtraTab;
using DevExpress.XtraTab.ViewInfo;
using System.Text.RegularExpressions;

namespace QuanLyGiuongBenhVien
{
    public partial class Main : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        private static XtraTabControl tabstatic;
        public static string user;
        public static string idLogin;
        public Main()
        {
            InitializeComponent();
            tabstatic = Tab_Main;
        }
        public static bool IsSuccessfull = false;
        SqlConnection cls_KetNoi = new SqlConnection();
        //Hàm thay đổi skin
        private void skin()
        {
            DevExpress.LookAndFeel.DefaultLookAndFeel themes = new DevExpress.LookAndFeel.DefaultLookAndFeel();
            themes.LookAndFeel.SkinName = "Springtime";
        }
        //Hàm ẩn không cho thao tác lên phần mềm khi chưa đăng nhập
        public void DisEndMenuLogin(bool e, string _idLogin)
        {
            btnLogin.Enabled = e;
            btnDoimatkhau.Enabled = !e;
            btnLogout.Enabled = !e;
            btn_BacSy.Enabled = !e;
            btn_BenhNhan.Enabled = !e;
            btn_GiuongBenh.Enabled = !e;
            btn_PhongBenh.Enabled = !e;
            btn_PC.Enabled = !e;
            btn_SapXepBN.Enabled = !e;
            btn_HoaDon.Enabled = !e;
        }
        //Các hàm bật/mở Tab
        public static bool KiemTraTabPage(string Ten)
        {
            bool ok = false;
            foreach (XtraTabPage tabpage in tabstatic.TabPages)
            {
                if (tabpage.Text == Ten)
                {
                    return ok = true;
                }
            }
            return ok;
        }
        public static int ViTriTabPage(string Ten)
        {
            int vitri = 0;
            for (int i = 0; i < tabstatic.TabPages.Count; i++)
            {
                if (tabstatic.TabPages[i].Text == Ten)
                    vitri = i;
            }
            return vitri;
        }
        //Đăng nhập
        private void btnLogin_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Login login = null;
            Check_Login:
            if (login == null || login.IsDisposed)
                login = new Login();
            if (login.ShowDialog() == DialogResult.OK)
            {
                if (login.txtName.Text == "")
                {
                    XtraMessageBox.Show("Hãy nhập vào Username !");
                    goto Check_Login;
                }
                if (login.txtPass.Text == "")
                {
                    XtraMessageBox.Show("Hãy nhập vào Password !");
                    goto Check_Login;
                }
                string check = "";
                string username = login.txtName.Text;
                string password = login.txtPass.Text;
                check = Controllers.LoginCtrl.CheckDangNhap(username, password);
                if (check == "")
                {
                    XtraMessageBox.Show("Đăng nhập thất bại . Kiểm tra lại username hoặc password !");
                    goto Check_Login;
                }
                else
                {
                    DisEndMenuLogin(false, idLogin);
                }
            }
        }
        private void Main_Load(object sender, EventArgs e)
        {
            DisEndMenuLogin(true, idLogin);
            skin();
        }
        //Thoát chương trình
        private void btnExit_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (MessageBox.Show("Bạn Có Muốn Thoát?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }
        //Đăng xuất
        private void btnLogout_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (XtraMessageBox.Show("Bạn có muốn đăng xuất ? ", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                DisEndMenuLogin(true, idLogin);
                Tab_BacSy.PageVisible = false;
                Tab_BenhNhan.PageVisible = false;
                Tab_GiuongBenh.PageVisible = false;
                Tab_PhongBenh.PageVisible = false;
                Tab_PhanCong.PageVisible = false;
                Tab_SapXepBenhNhan.PageVisible = false;
                Tab_HoaDon.PageVisible = false;
                btnLogin_ItemClick(sender, e);
            }
        }
        //Đổi mật khẩu
        private void btnDoimatkhau_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DoiMatKhau frmdoimatkhau = new DoiMatKhau();
            frmdoimatkhau.Show();
        }
        //Đóng Tab
        private void Tab_Main_CloseButtonClick(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn Có Muốn Đóng Trang ?", "Xác Nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Tab_Main.SelectedTabPage.PageVisible = false;
                Tab_GioiThieu.PageVisible = true;
        }
        //Hàm kiểm tra dữ liệu là số 
        private static bool IsNumber(string val)
        {
            if (val != "")
                return Regex.IsMatch(val, @"^[0-9]\d*\.?[0]*$");
            else return true;
        }
        //----------------------------------/* Bác Sỹ *\--------------------------------------
        DataTable Tb_BACSY_Select;
        //Load dữ liệu bác sỹ lên gridview
        
        private void LoadDSBS()
        {
            Tb_BACSY_Select = SqlHelper.ExecuteDataset(Connection.sqlcon, "BACSY_Select").Tables[0];
            grd_BacSy.DataSource = Tb_BACSY_Select;
        }
        //Tab Bác Sỹ
        private void btn_BacSy_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            XtraTabPage tabBacSy = new XtraTabPage();
            tabBacSy.Text = "Bác Sỹ";
            Tab_BacSy.PageVisible = true;
            Tab_Main.SelectedTabPage = Tab_Main.TabPages[ViTriTabPage(tabBacSy.Text)];
            LoadDSBS();
            LoadDSBSrow();
        }
        private void LoadDSBSrow()
        {
            txt_MaBacSy.Text = gridViewBacSy.GetRowCellValue(0, MaBS).ToString();
            txt_MaKhoa.Text = gridViewBacSy.GetRowCellValue(0, MaKhoa).ToString();
            txt_HoTen.Text = gridViewBacSy.GetRowCellValue(0, HoTen).ToString();
            det_NgaySinh.Text = gridViewBacSy.GetRowCellValue(0, NgaySinh).ToString();
            txt_CMND.Text = gridViewBacSy.GetRowCellValue(0, CMND).ToString();
            txt_DiaChi.Text = gridViewBacSy.GetRowCellValue(0, DiaChi).ToString();
            txt_Email.Text = gridViewBacSy.GetRowCellValue(0, Email).ToString();
            txt_SoDienThoai.Text = gridViewBacSy.GetRowCellValue(0, SoDienThoai).ToString();
            txt_TrinhDoCM.Text = gridViewBacSy.GetRowCellValue(0, TrinhDoChuyenMon).ToString();
            if (gridViewBacSy.GetRowCellValue(0, GioiTinh).ToString() == "Nam")
                rdb_Nam.Checked = true;
            else
                rdb_Nu.Checked = true;
        }
        private void gridViewBacSy_RowCellClick(object sender, DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs e)
        {
            txt_MaBacSy.Text = gridViewBacSy.GetFocusedDataRow()["MaBacSy"].ToString();
            txt_MaKhoa.Text = gridViewBacSy.GetFocusedDataRow()["MaKhoa"].ToString();
            txt_HoTen.Text = gridViewBacSy.GetFocusedDataRow()["HoTen"].ToString();
            det_NgaySinh.Text = gridViewBacSy.GetFocusedDataRow()["NgaySinh"].ToString();
            txt_CMND.Text = gridViewBacSy.GetFocusedDataRow()["CMND"].ToString();
            txt_DiaChi.Text = gridViewBacSy.GetFocusedDataRow()["DiaChi"].ToString();
            txt_Email.Text = gridViewBacSy.GetFocusedDataRow()["Email"].ToString();
            txt_SoDienThoai.Text = gridViewBacSy.GetFocusedDataRow()["SoDienThoai"].ToString();
            txt_TrinhDoCM.Text = gridViewBacSy.GetFocusedDataRow()["TrinhDoChuyenMon"].ToString();
            if (gridViewBacSy.GetFocusedDataRow()["GioiTinh"].ToString() == "Nam")
                rdb_Nam.Checked = true;
            else
                rdb_Nu.Checked = true;

        }

        private void gridViewBacSy_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
        }
        
        private void gridViewBacSy_MouseEnter(object sender, EventArgs e)
        {
        }

        string TestBtnBS = "";
        //Thêm Bác sỹ
        private void btn_ThemBS_Click(object sender, EventArgs e)
        {
            txt_MaBacSy.ReadOnly = false;
            txt_MaKhoa.ReadOnly = false;
            txt_HoTen.ReadOnly = false;
            rdb_Nam.Enabled = true;
            rdb_Nu.Enabled = true;
            det_NgaySinh.ReadOnly = false;
            txt_CMND.ReadOnly = false;
            txt_DiaChi.ReadOnly = false;
            txt_Email.ReadOnly = false;
            txt_SoDienThoai.ReadOnly = false;
            txt_TrinhDoCM.ReadOnly = false;
            btn_ThemBS.Enabled = false;
            btn_SuaBS.Enabled = false;
            btn_LuuBS.Enabled = true;
            btn_HuyBS.Enabled = true;
            btn_XoaBS.Enabled = false;
            TestBtnBS = "Them";
            txt_MaBacSy.Text = "";
            txt_MaKhoa.Text = "";
            txt_HoTen.Text = "";
            rdb_Nam.Checked = false;
            rdb_Nu.Checked = false;
            det_NgaySinh.Text = "";
            txt_CMND.Text = "";
            txt_DiaChi.Text = "";
            txt_Email.Text = "";
            txt_SoDienThoai.Text = "";
            txt_TrinhDoCM.Text = "";
            grd_BacSy.Enabled = false;
        }
        //Sửa Bác Sỹ
        private void btn_SuaBS_Click(object sender, EventArgs e)
        {
            txt_MaBacSy.ReadOnly = false;
            txt_MaKhoa.ReadOnly = false;
            txt_HoTen.ReadOnly = false;
            rdb_Nam.Enabled = true;
            rdb_Nu.Enabled = true;
            det_NgaySinh.ReadOnly = false;
            txt_CMND.ReadOnly = false;
            txt_DiaChi.ReadOnly = false;
            txt_Email.ReadOnly = false;
            txt_SoDienThoai.ReadOnly = false;
            txt_TrinhDoCM.ReadOnly = false;
            btn_ThemBS.Enabled = false;
            btn_SuaBS.Enabled = false;
            btn_LuuBS.Enabled = true;
            btn_HuyBS.Enabled = true;
            btn_XoaBS.Enabled = false;
            TestBtnBS = "Sua";
        }
        //Hủy Thêm/Sửa Bác Sỹ
        private void btn_HuyBS_Click(object sender, EventArgs e)
        {
            txt_MaBacSy.ReadOnly = true;
            txt_MaKhoa.ReadOnly = true;
            txt_HoTen.ReadOnly = true;
            rdb_Nam.Enabled = false;
            rdb_Nu.Enabled = false;
            det_NgaySinh.ReadOnly = true;
            txt_CMND.ReadOnly = true;
            txt_DiaChi.ReadOnly = true;
            txt_Email.ReadOnly = true;
            txt_SoDienThoai.ReadOnly = true;
            txt_TrinhDoCM.ReadOnly = true;
            btn_ThemBS.Enabled = true;
            btn_SuaBS.Enabled = true;
            btn_HuyBS.Enabled = false;
            btn_LuuBS.Enabled = false;
            btn_XoaBS.Enabled = true;
            grd_BacSy.Enabled = true;
        }
        //Lưu Thêm/Sửa Bác sỹ
        private void btn_LuuBS_Click(object sender, EventArgs e)
        {
            string gt = "";
            bool key = true;
            if (rdb_Nam.Checked)
                gt = "Nam";
            if (rdb_Nu.Checked)
                gt = "Nữ";
            try
            {
                for (int i = 0; i < Tb_BACSY_Select.Rows.Count; i++)
                {
                    if (txt_MaBacSy.Text == Tb_BACSY_Select.Rows[i][0].ToString())
                        key = false;
                }
                if (txt_MaBacSy.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã Bác Sỹ!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaBacSy.Focus();
                }
                else if (TestBtnBS == "Them" && key == false)
                {
                    MessageBox.Show("Mã Bác Sỹ Đã Có, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaBacSy.Focus();
                }
                else if (txt_MaKhoa.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã Khoa!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaKhoa.Focus();
                }
                else if (txt_HoTen.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Họ Tên!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_HoTen.Focus();
                }
                else if (rdb_Nam.Checked == false && rdb_Nu.Checked == false)
                {
                    MessageBox.Show("Bạn Chưa Nhập Giới Tính!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (det_NgaySinh.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Ngày Sinh!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    det_NgaySinh.Focus();
                }
                else if (txt_DiaChi.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Địa Chỉ!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_DiaChi.Focus();
                }
                else if (txt_CMND.Text=="")
                {
                    MessageBox.Show("Bạn Chưa Nhập CMND!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_CMND.Focus();
                }
                else if (IsNumber(txt_CMND.Text) == false)
                {
                    MessageBox.Show("Chứng minh nhân dân nhập vào không hợp lệ, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_CMND.Focus();
                }
                else if (txt_SoDienThoai.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Số điện thoại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_SoDienThoai.Focus();
                }
                else if (IsNumber(txt_SoDienThoai.Text) == false)
                {
                    MessageBox.Show("Số điện thoại nhập vào không hợp lệ, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_SoDienThoai.Focus();
                }
                else if (txt_Email.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Email!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_Email.Focus();
                }
                else if (txt_TrinhDoCM.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Trình độ chuyên môn!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_TrinhDoCM.Focus();
                }
                else if (TestBtnBS == "Them" && key == true)
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "BACSY_Insert", txt_MaBacSy.Text, txt_MaKhoa.Text, txt_HoTen.Text, gt, det_NgaySinh.Text, txt_CMND.Text,txt_DiaChi.Text,txt_Email.Text,txt_SoDienThoai.Text,txt_TrinhDoCM.Text);
                    MessageBox.Show("Đã thêm thông tin Bác sỹ ", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSBS();
                    btn_ThemBS.Enabled = true;
                    btn_SuaBS.Enabled = true;
                    btn_XoaBS.Enabled = true;
                    btn_LuuBS.Enabled = false;
                    btn_HuyBS.Enabled = false;
                    TestBtnBS = "";
                    grd_BacSy.Enabled = true;
                    txt_MaBacSy.ReadOnly = true;
                    txt_MaKhoa.ReadOnly = true;
                    txt_HoTen.ReadOnly = true;
                    rdb_Nam.Enabled = false;
                    rdb_Nu.Enabled = false;
                    det_NgaySinh.ReadOnly = true;
                    txt_CMND.ReadOnly = true;
                    txt_DiaChi.ReadOnly = true;
                    txt_Email.ReadOnly = true;
                    txt_SoDienThoai.ReadOnly = true;
                    txt_TrinhDoCM.ReadOnly = true;
                }
                else if (TestBtnBS == "Sua")
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "BACSY_Update", txt_MaBacSy.Text, txt_MaKhoa.Text, txt_HoTen.Text, gt, det_NgaySinh.Text, txt_CMND.Text, txt_DiaChi.Text, txt_Email.Text, txt_SoDienThoai.Text, txt_TrinhDoCM.Text);
                    MessageBox.Show("Đã sửa thông tin Bác sỹ ", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSBS();
                    btn_ThemBS.Enabled = true;
                    btn_SuaBS.Enabled = true;
                    btn_XoaBS.Enabled = true;
                    btn_LuuBS.Enabled = false;
                    btn_HuyBS.Enabled = false;
                    TestBtnBS = "";
                    txt_MaBacSy.ReadOnly = true;
                    txt_MaKhoa.ReadOnly = true;
                    txt_HoTen.ReadOnly = true;
                    rdb_Nam.Enabled = false;
                    rdb_Nu.Enabled = false;
                    det_NgaySinh.ReadOnly = true;
                    txt_CMND.ReadOnly = true;
                    txt_DiaChi.ReadOnly = true;
                    txt_Email.ReadOnly = true;
                    txt_SoDienThoai.ReadOnly = true;
                    txt_TrinhDoCM.ReadOnly = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui Lòng Nhập Đúng Kiểu Dữ Liệu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Xóa Bác Sỹ
        private void btn_XoaBS_Click(object sender, EventArgs e)
        {
            if (Tb_BACSY_Select.Rows.Count > 0)
            {
                try
                {
                    if (MessageBox.Show("Bạn Có Muốn Xóa?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SqlHelper.ExecuteNonQuery(Connection.sqlcon, "BACSY_Delete", txt_MaBacSy.Text);
                        MessageBox.Show("Xóa Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDSBS();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không Thể Xóa, Vui Lòng Kiểm Tra Lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
                MessageBox.Show("Dữ Liệu Trống,Không Thể Xóa!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        //Refresh thông tin bác sỹ
        private void btn_LoadBS_Click(object sender, EventArgs e)
        {
            LoadDSBS();
            LoadDSBSrow();
        }
        //Tìm kiếm theo mã bác sỹ
        private void rdb_MaBS_CheckedChanged(object sender, EventArgs e)
        {
            btn_HuySearchBS.Enabled = true;
            txt_SearchMaBS.Text = "";
            txt_SearchMaBS.Enabled = true;
            txt_SearchTenBS.Enabled = false;
            LoadDSBS();
        }
        private void txt_SearchMaBS_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_SearchMaBS.Text.Length > 0 && rdb_MaBS.Checked == false)
                    MessageBox.Show("Vui Lòng Chọn Đúng Kiểu Tìm Kiếm!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else if (rdb_MaBS.Checked == true)
                {
                    grd_BacSy.DataSource = SqlHelper.ExecuteDataset(Connection.sqlcon, "BACSY_Select_MaBS", txt_SearchMaBS.Text).Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui lòng nhập đúng mã bác sỹ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //tìm kiếm theo tên bác sỹ
        private void rdb_TenBS_CheckedChanged(object sender, EventArgs e)
        {
            btn_HuySearchBS.Enabled = true;
            txt_SearchTenBS.Text = "";
            txt_SearchTenBS.Enabled = true;
            txt_SearchMaBS.Enabled = false;
            LoadDSBS();
        }
        private void txt_SearchTenBS_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_SearchTenBS.Text.Length > 0 && rdb_TenBS.Checked == false)
                    MessageBox.Show("Vui Lòng Chọn Đúng Kiểu Tìm Kiếm!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else if (rdb_TenBS.Checked == true)
                {
                    grd_BacSy.DataSource = SqlHelper.ExecuteDataset(Connection.sqlcon, "BACSY_Select_TenBS", txt_SearchTenBS.Text).Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui lòng nhập đúng tên bác sỹ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Hủy tìm kiếm bác sỹ
        private void btn_HuySearchBS_Click(object sender, EventArgs e)
        {
            txt_SearchMaBS.Text = "";
            txt_SearchTenBS.Text = "";
            txt_SearchMaBS.Enabled = true;
            txt_SearchTenBS.Enabled = true;
            rdb_MaBS.Checked = false;
            rdb_TenBS.Checked = false;
            btn_HuySearchBS.Enabled = false;
        }
        //--------------------------------------/* Bệnh Nhân *\----------------------------------------
        DataTable Tb_BENHNHAN_Select;
        //Load dữ liệu bệnh nhân lên gridview
        private void LoadDSBN()
        {
            Tb_BENHNHAN_Select = SqlHelper.ExecuteDataset(Connection.sqlcon, "BENHNHAN_Select").Tables[0];
            grd_BenhNhan.DataSource = Tb_BENHNHAN_Select;
        }
        //Tab Bệnh Nhân
        private void btn_BenhNhan_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            XtraTabPage tabBenhNhan = new XtraTabPage();
            tabBenhNhan.Text = "Bệnh Nhân";
            Tab_BenhNhan.PageVisible = true;
            Tab_Main.SelectedTabPage = Tab_Main.TabPages[ViTriTabPage(tabBenhNhan.Text)];
            LoadDSBN();
            LoadDSBNrow();
        }
        private void LoadDSBNrow()
        {
            txt_MaBN.Text = gridViewBenhNhan.GetRowCellValue(0, MaBN).ToString();
            txt_HoTenBN.Text = gridViewBenhNhan.GetRowCellValue(0, HoTenBN).ToString();
            det_NgaySinhBN.Text = gridViewBenhNhan.GetRowCellValue(0, NgaySinhBN).ToString();
            txt_DiaChiBN.Text = gridViewBenhNhan.GetRowCellValue(0, DiaChiBN).ToString();
            txt_CMNDBN.Text = gridViewBenhNhan.GetRowCellValue(0, CMNDBN).ToString();
            txt_DiaChiBN.Text = gridViewBenhNhan.GetRowCellValue(0, DiaChiBN).ToString();
            txt_NoiSinhBN.Text = gridViewBenhNhan.GetRowCellValue(0, NoiSinhBN).ToString();
            txt_SdtBN.Text = gridViewBenhNhan.GetRowCellValue(0,sdtBN).ToString();
            txt_NgheNghiepBN.Text = gridViewBenhNhan.GetRowCellValue(0, NgheNghiepBN).ToString();
            txt_EmailBN.Text = gridViewBenhNhan.GetRowCellValue(0, EmailBN).ToString();
            if (gridViewBenhNhan.GetRowCellValue(0,GioiTinhBN).ToString() == "Nam")
                rdb_NamBN.Checked = true;
            else
                rdb_NuBN.Checked = true;
        }
        private void gridViewBenhNhan_RowCellClick(object sender, DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs e)
        {
            txt_MaBN.Text = gridViewBenhNhan.GetFocusedDataRow()["MaSoBenhNhan"].ToString();
            txt_HoTenBN.Text = gridViewBenhNhan.GetFocusedDataRow()["HoTen"].ToString();
            det_NgaySinhBN.Text = gridViewBenhNhan.GetFocusedDataRow()["NgaySinh"].ToString();
            txt_DiaChiBN.Text = gridViewBenhNhan.GetFocusedDataRow()["DiaChi"].ToString();
            txt_CMNDBN.Text = gridViewBenhNhan.GetFocusedDataRow()["CMND"].ToString();
            txt_DiaChiBN.Text = gridViewBenhNhan.GetFocusedDataRow()["DiaChi"].ToString();
            txt_NoiSinhBN.Text = gridViewBenhNhan.GetFocusedDataRow()["NoiSinh"].ToString();
            txt_SdtBN.Text = gridViewBenhNhan.GetFocusedDataRow()["SoDienThoai"].ToString();
            txt_NgheNghiepBN.Text = gridViewBenhNhan.GetFocusedDataRow()["NgheNghiep"].ToString();
            txt_EmailBN.Text = gridViewBenhNhan.GetFocusedDataRow()["Email"].ToString();
            if (gridViewBenhNhan.GetFocusedDataRow()["GioiTinh"].ToString() == "Nam")
                rdb_NamBN.Checked = true;
            else
                rdb_NuBN.Checked = true;
        }
        private void gridViewBenhNhan_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            
        }
        //Thêm Bệnh nhân
        string TestbtnBN = "";
        private void btn_ThemBN_Click(object sender, EventArgs e)
        {
            txt_MaBN.ReadOnly = false;
            txt_HoTenBN.ReadOnly = false;
            det_NgaySinhBN.ReadOnly = false;
            txt_DiaChiBN.ReadOnly = false;
            txt_CMNDBN.ReadOnly = false;
            txt_EmailBN.ReadOnly = false;
            txt_NgheNghiepBN.ReadOnly = false;
            txt_SdtBN.ReadOnly = false;
            txt_NoiSinhBN.ReadOnly = false;
            rdb_NamBN.Enabled = true;
            rdb_NuBN.Enabled = true;
            rdb_NuBN.Checked = false;
            rdb_NamBN.Checked = false;
            btn_ThemBN.Enabled = false;
            btn_SuaBN.Enabled = false;
            btn_LuuBN.Enabled = true;
            btn_HuyBN.Enabled = true;
            btn_XoaBN.Enabled = false;
            txt_MaBN.Text = "";
            txt_HoTenBN.Text = "";
            txt_DiaChiBN.Text = "";
            txt_EmailBN.Text = "";
            txt_CMNDBN.Text = "";
            txt_SdtBN.Text = "";
            txt_NgheNghiepBN.Text = "";
            txt_NoiSinhBN.Text = "";
            det_NgaySinhBN.Text = "";
            TestbtnBN = "Them";
            grd_BenhNhan.Enabled = false;
        }
        //Sửa bệnh nhân
        private void btn_SuaBN_Click(object sender, EventArgs e)
        {
            txt_MaBN.ReadOnly = false;
            txt_HoTenBN.ReadOnly = false;
            det_NgaySinhBN.ReadOnly = false;
            txt_DiaChiBN.ReadOnly = false;
            txt_CMNDBN.ReadOnly = false;
            txt_EmailBN.ReadOnly = false;
            txt_NgheNghiepBN.ReadOnly = false;
            txt_SdtBN.ReadOnly = false;
            txt_NoiSinhBN.ReadOnly = false;
            rdb_NamBN.Enabled = true;
            rdb_NuBN.Enabled = true;
            btn_ThemBN.Enabled = false;
            btn_SuaBN.Enabled = false;
            btn_LuuBN.Enabled = true;
            btn_HuyBN.Enabled = true;
            btn_XoaBN.Enabled = false;
            TestbtnBN = "Sua";
        }
        //Huỷ Thêm/Sửa Bệnh nhân
        private void btn_HuyBN_Click(object sender, EventArgs e)
        {
            txt_MaBN.ReadOnly = true;
            txt_HoTenBN.ReadOnly = true;
            det_NgaySinhBN.ReadOnly = true;
            txt_DiaChiBN.ReadOnly = true;
            txt_CMNDBN.ReadOnly = true;
            txt_EmailBN.ReadOnly = true;
            txt_NgheNghiepBN.ReadOnly = true;
            txt_SdtBN.ReadOnly = true;
            txt_NoiSinhBN.ReadOnly = true;
            rdb_NamBN.Enabled = false;
            rdb_NuBN.Enabled = false;
            btn_ThemBN.Enabled = true;
            btn_SuaBN.Enabled = true;
            btn_LuuBN.Enabled = false;
            btn_HuyBN.Enabled = false;
            btn_XoaBN.Enabled = true;
            grd_BenhNhan.Enabled = true;
        }
        //Lưu Thêm/Sửa Bệnh nhân
        private void btn_LuuBN_Click(object sender, EventArgs e)
        {
            string gt = "";
            bool key = true;
            if (rdb_NamBN.Checked)
                gt = "Nam";
            if (rdb_NuBN.Checked)
                gt = "Nữ";
            try
            {
                for (int i = 0; i < Tb_BENHNHAN_Select.Rows.Count; i++)
                {
                    if (txt_MaBN.Text == Tb_BENHNHAN_Select.Rows[i][0].ToString())
                        key = false;
                }
                if (txt_MaBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã Bệnh nhân!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaBN.Focus();
                }
                else if (TestbtnBN == "Them" && key == false)
                {
                    MessageBox.Show("Mã Bệnh nhân Đã Có, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaBN.Focus();
                }
                else if (txt_HoTenBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Họ Tên!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_HoTenBN.Focus();
                }
                else if (rdb_NamBN.Checked == false && rdb_NuBN.Checked == false)
                {
                    MessageBox.Show("Bạn Chưa Nhập Giới Tính!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (det_NgaySinhBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Ngày Sinh!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    det_NgaySinhBN.Focus();
                }
                else if (txt_DiaChiBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Địa Chỉ!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_DiaChiBN.Focus();
                }
                else if (txt_CMNDBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập CMND!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_CMNDBN.Focus();
                }
                else if (IsNumber(txt_CMNDBN.Text) == false)
                {
                    MessageBox.Show("Chứng minh nhân dân nhập vào không hợp lệ, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_CMNDBN.Focus();
                }
                else if (txt_SdtBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Số điện thoại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_SdtBN.Focus();
                }
                else if (IsNumber(txt_SdtBN.Text) == false)
                {
                    MessageBox.Show("Số điện thoại nhập vào không hợp lệ, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_SdtBN.Focus();
                }
                else if (txt_NoiSinhBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Nơi sinh", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_NoiSinhBN.Focus();
                }
                else if (txt_EmailBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Email!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_EmailBN.Focus();
                }
                else if (txt_NgheNghiepBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập nghề nghiệp!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_NgheNghiepBN.Focus();
                }
                else if (TestbtnBN == "Them" && key == true)
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "BENHNHAN_Insert", txt_MaBN.Text,txt_HoTenBN.Text, gt,txt_DiaChiBN.Text, det_NgaySinhBN.Text,txt_NoiSinhBN.Text, txt_CMNDBN.Text,txt_SdtBN.Text,txt_NgheNghiepBN.Text,txt_EmailBN.Text);
                    MessageBox.Show("Đã thêm thông tin bệnh nhân nhập viện ", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSBN();
                    btn_ThemBN.Enabled = true;
                    btn_SuaBN.Enabled = true;
                    btn_XoaBN.Enabled = true;
                    btn_LuuBN.Enabled = false;
                    btn_HuyBN.Enabled = false;
                    TestbtnBN = "";
                    grd_BenhNhan.Enabled = true;
                    txt_MaBN.ReadOnly = true;
                    txt_HoTenBN.ReadOnly = true;
                    det_NgaySinhBN.ReadOnly = true;
                    txt_DiaChiBN.ReadOnly = true;
                    txt_CMNDBN.ReadOnly = true;
                    txt_EmailBN.ReadOnly = true;
                    txt_NgheNghiepBN.ReadOnly = true;
                    txt_SdtBN.ReadOnly = true;
                    txt_NoiSinhBN.ReadOnly = true;
                    rdb_NamBN.Enabled = false;
                    rdb_NuBN.Enabled = false;
                }
                else if (TestbtnBN == "Sua")
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "BENHNHAN_Update", txt_MaBN.Text, txt_HoTenBN.Text, gt, txt_DiaChiBN.Text, det_NgaySinhBN.Text, txt_NoiSinhBN.Text, txt_CMNDBN.Text, txt_SdtBN.Text, txt_NgheNghiepBN.Text, txt_EmailBN.Text);
                    MessageBox.Show("Sửa thông tin bệnh nhân thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSBN();
                    btn_ThemBN.Enabled = true;
                    btn_SuaBN.Enabled = true;
                    btn_XoaBN.Enabled = true;
                    btn_LuuBN.Enabled = false;
                    btn_HuyBN.Enabled = false;
                    TestbtnBN = "";
                    txt_MaBN.ReadOnly = true;
                    txt_HoTenBN.ReadOnly = true;
                    det_NgaySinhBN.ReadOnly = true;
                    txt_DiaChiBN.ReadOnly = true;
                    txt_CMNDBN.ReadOnly = true;
                    txt_EmailBN.ReadOnly = true;
                    txt_NgheNghiepBN.ReadOnly = true;
                    txt_SdtBN.ReadOnly = true;
                    txt_NoiSinhBN.ReadOnly = true;
                    rdb_NamBN.Enabled = false;
                    rdb_NuBN.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui Lòng Nhập Đúng Kiểu Dữ Liệu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Xóa bệnh nhân khi bệnh nhân xuất viện 
        private void btn_XoaBN_Click(object sender, EventArgs e)
        {
            if (Tb_BENHNHAN_Select.Rows.Count > 0)
            {
                try
                {
                    if (MessageBox.Show("Cho bệnh nhân xuất viện?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SqlHelper.ExecuteNonQuery(Connection.sqlcon, "BENHNHAN_Delete", txt_MaBN.Text);
                        MessageBox.Show("Bệnh nhân đã xuất viện", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDSBN();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không Thể Xóa, Vui Lòng Kiểm Tra Lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
                MessageBox.Show("Dữ Liệu Trống,Không Thể Xóa!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        //Refresh thông tin bệnh nhân
        private void btn_LoadBN_Click(object sender, EventArgs e)
        {
            LoadDSBN();
            LoadDSBNrow();
        }
        //Tìm kiếm theo mã bệnh nhân
        private void rdb_MaBN_CheckedChanged(object sender, EventArgs e)
        {
            btn_HuySearchBN.Enabled = true;
            txt_SearchMaBN.Text = "";
            txt_SearchMaBN.Enabled = true;
            txt_SearchTenBN.Enabled = false;
            LoadDSBN();
        }
        private void txt_SearchMaBN_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_SearchMaBN.Text.Length > 0 && rdb_MaBN.Checked == false)
                    MessageBox.Show("Vui Lòng Chọn Đúng Kiểu Tìm Kiếm!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else if (rdb_MaBN.Checked == true)
                {
                    grd_BenhNhan.DataSource = SqlHelper.ExecuteDataset(Connection.sqlcon, "BENHNHAN_Select_MaBN", txt_SearchMaBN.Text).Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui lòng nhập đúng mã bệnh nhân!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Tìm kiếm theo tên bệnh nhân
        private void rdb_TenBN_CheckedChanged(object sender, EventArgs e)
        {
            btn_HuySearchBN.Enabled = true;
            txt_SearchTenBN.Text = "";
            txt_SearchTenBN.Enabled = true;
            txt_SearchMaBN.Enabled = false;
            LoadDSBN();
        }
        private void txt_SearchTenBN_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_SearchTenBN.Text.Length > 0 && rdb_TenBN.Checked == false)
                    MessageBox.Show("Vui Lòng Chọn Đúng Kiểu Tìm Kiếm!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else if (rdb_TenBN.Checked == true)
                {
                    grd_BenhNhan.DataSource = SqlHelper.ExecuteDataset(Connection.sqlcon, "BENHNHAN_Select_TenBN", txt_SearchTenBN.Text).Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui lòng nhập đúng tên bệnh nhân!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_HuySearchBN_Click(object sender, EventArgs e)
        {
            txt_SearchMaBN.Text = "";
            txt_SearchTenBN.Text = "";
            txt_SearchMaBN.Enabled = true;
            txt_SearchTenBN.Enabled = true;
            rdb_MaBN.Checked = false;
            rdb_TenBN.Checked = false;
            btn_HuySearchBN.Enabled = false;
        }
        //----------------------------------/* Giường Bệnh *\-------------------------------------
        DataTable Tb_GIUONGBENH_Select;
        private void LoadDSGB()
        {
            Tb_GIUONGBENH_Select = SqlHelper.ExecuteDataset(Connection.sqlcon, "GIUONGBENH_Select").Tables[0];
            grd_GiuongBenh.DataSource = Tb_GIUONGBENH_Select;
        }
        //Tab Giường Bệnh
        private void btn_GiuongBenh_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            XtraTabPage tabGiuongBenh = new XtraTabPage();
            tabGiuongBenh.Text = "Giường Bệnh";
            Tab_GiuongBenh.PageVisible = true;
            Tab_Main.SelectedTabPage = Tab_Main.TabPages[ViTriTabPage(tabGiuongBenh.Text)];
            LoadDSGB();
        }
        private void gridViewGiuongBenh_RowCellClick(object sender, DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs e)
        {
            
        }
        private void gridViewGiuongBenh_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            txt_MaGiuongBenh.Text = gridViewGiuongBenh.GetFocusedDataRow()["MaGiuongBenh"].ToString();
            txt_LoaiGiuongBenh.Text = gridViewGiuongBenh.GetFocusedDataRow()["LoaiGiuong"].ToString();
            txt_MaPhong.Text = gridViewGiuongBenh.GetFocusedDataRow()["MaPhongBenh"].ToString();
            if (gridViewGiuongBenh.GetFocusedDataRow()["DaCoNguoiNam"].ToString() == "True")
                checkE_NguoiNam.Checked = true;
            else
                checkE_NguoiNam.Checked = false;
        }
        //Thêm giường bệnh
        string TestbtnGB = "";
        private void btn_ThemGB_Click(object sender, EventArgs e)
        {
            btn_ThemGB.Enabled = false;
            btn_SuaGB.Enabled = false;
            btn_LuuGB.Enabled = true;
            btn_HuyGB.Enabled = true;
            btn_XoaGB.Enabled = false;
            txt_MaGiuongBenh.ReadOnly = false;
            txt_LoaiGiuongBenh.ReadOnly = false;
            txt_MaPhong.Enabled = true;
            checkE_NguoiNam.ReadOnly = false;
            txt_MaGiuongBenh.Text = "";
            txt_LoaiGiuongBenh.Text = "";
            txt_MaPhong.Text = "";
            checkE_NguoiNam.Checked = false;
            grd_GiuongBenh.Enabled = false;
            TestbtnGB = "Them";
        }
        //Sửa giường bệnh khi bệnh nhân xuất viện hoặc chuyển giường/phòng
        private void btn_SuaGB_Click(object sender, EventArgs e)
        {
            btn_ThemGB.Enabled = false;
            btn_SuaGB.Enabled = false;
            btn_LuuGB.Enabled = true;
            btn_HuyGB.Enabled = true;
            btn_XoaGB.Enabled = false;
            txt_MaGiuongBenh.ReadOnly = false;
            txt_LoaiGiuongBenh.ReadOnly = false;
            txt_MaPhong.Enabled = true;
            checkE_NguoiNam.ReadOnly = false;
            TestbtnGB = "Sua";
        }
        //Hủy thêm/sửa giường bệnh
        private void btn_HuyGB_Click(object sender, EventArgs e)
        {
            btn_ThemGB.Enabled = true;
            btn_SuaGB.Enabled = true;
            btn_LuuGB.Enabled = false;
            btn_HuyGB.Enabled = false;
            btn_XoaGB.Enabled = true;
            txt_MaGiuongBenh.ReadOnly = true;
            txt_LoaiGiuongBenh.ReadOnly = true;
            txt_MaPhong.Enabled = false;
            checkE_NguoiNam.ReadOnly = true;
            grd_GiuongBenh.Enabled = true;
        }
        //Lưu thêm/sửa giường bệnh
        private void btn_LuuGB_Click(object sender, EventArgs e)
        {
            string kt = "";
            bool key = true;
            if (checkE_NguoiNam.Checked)
                kt = "True";
            else
                kt = "False";
            try
            {
                for (int i = 0; i < Tb_GIUONGBENH_Select.Rows.Count; i++)
                {
                    if (txt_MaGiuongBenh.Text == Tb_GIUONGBENH_Select.Rows[i][0].ToString())
                        key = false;
                }
                if (txt_MaGiuongBenh.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã giường bệnh!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaGiuongBenh.Focus();
                }
                else if (TestbtnGB == "Them" && key == false)
                {
                    MessageBox.Show("Mã Giường Bệnh Đã Có, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaGiuongBenh.Focus();
                }
                else if (txt_LoaiGiuongBenh.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Loại giường!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_LoaiGiuongBenh.Focus();
                }
                else if (txt_MaPhong.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã Phòng Bệnh!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaPhong.Focus();
                }
                
                else if (TestbtnGB == "Them" && key == true)
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "GIUONGBENH_Insert", txt_MaGiuongBenh.Text,txt_LoaiGiuongBenh.Text,txt_MaPhong.Text,kt);
                    MessageBox.Show("Đã thêm giường bệnh vào phòng", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSGB();
                    btn_ThemGB.Enabled = true;
                    btn_SuaGB.Enabled = true;
                    btn_LuuGB.Enabled = false;
                    btn_HuyGB.Enabled = false;
                    btn_XoaGB.Enabled = true;
                    TestbtnGB = "";
                    grd_GiuongBenh.Enabled = true;
                    txt_MaGiuongBenh.ReadOnly = true;
                    txt_LoaiGiuongBenh.ReadOnly = true;
                    txt_MaPhong.Enabled = false;
                    checkE_NguoiNam.ReadOnly = true;
                }
                else if (TestbtnGB == "Sua")
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "GIUONGBENH_Update", txt_MaGiuongBenh.Text, txt_LoaiGiuongBenh.Text,txt_MaPhong.Text, kt);
                    MessageBox.Show("Sửa thông tin giường thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSGB();
                    btn_ThemGB.Enabled = true;
                    btn_SuaGB.Enabled = true;
                    btn_LuuGB.Enabled = false;
                    btn_HuyGB.Enabled = false;
                    btn_XoaGB.Enabled = true;
                    TestbtnGB = "";
                    grd_GiuongBenh.Enabled = true;
                    txt_MaGiuongBenh.ReadOnly = true;
                    txt_LoaiGiuongBenh.ReadOnly = true;
                    txt_MaPhong.Enabled = false;
                    checkE_NguoiNam.ReadOnly = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui Lòng Nhập Đúng Kiểu Dữ Liệu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Xóa giường bệnh 
        private void btn_XoaGB_Click(object sender, EventArgs e)
        {
            if (Tb_GIUONGBENH_Select.Rows.Count > 0)
            {
                try
                {
                    if (MessageBox.Show("Bạn Có Muốn Xóa?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SqlHelper.ExecuteNonQuery(Connection.sqlcon, "GIUONGBENH_Delete", txt_MaGiuongBenh.Text);
                        MessageBox.Show("Đã xóa giường bệnh ", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDSGB();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không Thể Xóa, Vui Lòng Kiểm Tra Lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
                MessageBox.Show("Dữ Liệu Trống,Không Thể Xóa!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        //Refresh thông tin giường bệnh
        private void btn_LoadGB_Click(object sender, EventArgs e)
        {
            LoadDSGB();
        }
        //-----------------------------------/* Phòng Bệnh *\---------------------------------
        DataTable Tb_PHONGBENH_Select;
        private void LoadDSPB()
        {
            Tb_PHONGBENH_Select = SqlHelper.ExecuteDataset(Connection.sqlcon, "PHONGBENH_Select").Tables[0];
            grd_PhongBenh.DataSource = Tb_PHONGBENH_Select;
        }
        //Tab phòng bệnh
        private void btn_PhongBenh_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            XtraTabPage tabPhongBenh = new XtraTabPage();
            tabPhongBenh.Text = "Phòng Bệnh";
            Tab_PhongBenh.PageVisible = true;
            Tab_Main.SelectedTabPage = Tab_Main.TabPages[ViTriTabPage(tabPhongBenh.Text)];
            LoadDSPB();
        }
        private void gridViewPhongBenh_RowCellClick(object sender, DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs e)
        {
            
        }
        private void gridViewPhongBenh_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            txt_MaPB.Text = gridViewPhongBenh.GetFocusedDataRow()["MaPhongBenh"].ToString();
            txt_TenPhongBenh.Text = gridViewPhongBenh.GetFocusedDataRow()["TenPhong"].ToString();
            txt_LoaiPhong.Text = gridViewPhongBenh.GetFocusedDataRow()["LoaiPhong"].ToString();
            txt_SoGiuongBenh.Text = gridViewPhongBenh.GetFocusedDataRow()["SoGiuong"].ToString();
            if (gridViewPhongBenh.GetFocusedDataRow()["PhongSuDungDuoc"].ToString() == "True")
                checkE_PhongBenh.Checked = true;
            else
                checkE_PhongBenh.Checked = false;
        }
        //Thêm Phòng bệnh
        string TestbtnPB = "";
        private void btn_ThemPB_Click(object sender, EventArgs e)
        {
            btn_ThemPB.Enabled = false;
            btn_SuaPB.Enabled = false;
            btn_LuuPB.Enabled = true;
            btn_HuyPB.Enabled = true;
            btn_XoaPB.Enabled = false;
            txt_MaPB.ReadOnly = false;
            txt_TenPhongBenh.ReadOnly = false;
            txt_LoaiPhong.ReadOnly = false;
            txt_SoGiuongBenh.ReadOnly = false;
            checkE_PhongBenh.ReadOnly = false;
            checkE_PhongBenh.Checked = false;
            txt_MaPB.Text = "";
            txt_TenPhongBenh.Text = "";
            txt_LoaiPhong.Text = "";
            txt_SoGiuongBenh.Text = "";
            grd_PhongBenh.Enabled = false;
            TestbtnPB = "Them";
        }
        //Sửa phòng bệnh
        private void btn_SuaPB_Click(object sender, EventArgs e)
        {
            btn_ThemPB.Enabled = false;
            btn_SuaPB.Enabled = false;
            btn_LuuPB.Enabled = true;
            btn_HuyPB.Enabled = true;
            btn_XoaPB.Enabled = false;
            txt_MaPB.ReadOnly = false;
            txt_TenPhongBenh.ReadOnly = false;
            txt_LoaiPhong.ReadOnly = false;
            txt_SoGiuongBenh.ReadOnly = false;
            checkE_PhongBenh.ReadOnly = false;
            TestbtnPB = "Sua";
        }
        //Hủy Thêm/Sủa phòng bệnh
        private void btn_HuyPB_Click(object sender, EventArgs e)
        {
            btn_ThemPB.Enabled = true;
            btn_SuaPB.Enabled = true;
            btn_LuuPB.Enabled = false;
            btn_HuyPB.Enabled = false;
            btn_XoaPB.Enabled = true;
            txt_MaPB.ReadOnly = true;
            txt_TenPhongBenh.ReadOnly = true;
            txt_LoaiPhong.ReadOnly = true;
            txt_SoGiuongBenh.ReadOnly = true;
            checkE_PhongBenh.ReadOnly = true;
            grd_PhongBenh.Enabled = true;
        }

        private void btn_LuuPB_Click(object sender, EventArgs e)
        {
            string kt = "";
            bool key = true;
            if (checkE_PhongBenh.Checked)
                kt = "True";
            else
                kt = "False";
            try
            {
                for (int i = 0; i < Tb_PHONGBENH_Select.Rows.Count; i++)
                {
                    if (txt_MaPB.Text == Tb_PHONGBENH_Select.Rows[i][0].ToString())
                        key = false;
                }
                if (txt_MaPB.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã phòng bệnh!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaPB.Focus();
                }
                else if (TestbtnPB == "Them" && key == false)
                {
                    MessageBox.Show("Mã Phòng Bệnh Đã Có, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaPB.Focus();
                }
                else if (txt_TenPhongBenh.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập tên phòng!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_TenPhongBenh.Focus();
                }
                else if (txt_LoaiPhong.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Loại phòng!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_LoaiPhong.Focus();
                }
                else if (txt_SoGiuongBenh.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Số Giường Bệnh!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_SoGiuongBenh.Focus();
                }
                else if (IsNumber(txt_SoGiuongBenh.Text) == false)
                {
                    MessageBox.Show("Số giường bệnh nhập vào không hợp lệ, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_SoGiuongBenh.Focus();
                }
                else if (TestbtnPB == "Them" && key == true)
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "PHONGBENH_Insert", txt_MaPB.Text, txt_TenPhongBenh.Text,txt_LoaiPhong.Text,txt_SoGiuongBenh.Text, kt);
                    MessageBox.Show("Thêm thông tin phòng bệnh thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSPB();
                    btn_ThemPB.Enabled = true;
                    btn_SuaPB.Enabled = true;
                    btn_LuuPB.Enabled = false;
                    btn_HuyPB.Enabled = false;
                    btn_XoaPB.Enabled = true;
                    txt_MaPB.ReadOnly = true;
                    txt_TenPhongBenh.ReadOnly = true;
                    txt_LoaiPhong.ReadOnly = true;
                    txt_SoGiuongBenh.ReadOnly = true;
                    checkE_PhongBenh.ReadOnly = true;
                    grd_PhongBenh.Enabled = true;
                    TestbtnPB = "";
                }
                else if (TestbtnPB == "Sua")
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "PHONGBENH_Update", txt_MaPB.Text, txt_TenPhongBenh.Text, txt_LoaiPhong.Text, txt_SoGiuongBenh.Text, kt);
                    MessageBox.Show("Sửa thông tin phòng bệnh thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSPB();
                    btn_ThemPB.Enabled = true;
                    btn_SuaPB.Enabled = true;
                    btn_LuuPB.Enabled = false;
                    btn_HuyPB.Enabled = false;
                    btn_XoaPB.Enabled = true;
                    txt_MaPB.ReadOnly = true;
                    txt_TenPhongBenh.ReadOnly = true;
                    txt_LoaiPhong.ReadOnly = true;
                    txt_SoGiuongBenh.ReadOnly = true;
                    checkE_PhongBenh.ReadOnly = true;
                    grd_PhongBenh.Enabled = true;
                    TestbtnPB = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui Lòng Nhập Đúng Kiểu Dữ Liệu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Xóa phòng bệnh
        private void btn_XoaPB_Click(object sender, EventArgs e)
        {
            if (Tb_PHONGBENH_Select.Rows.Count > 0)
            {
                try
                {
                    if (MessageBox.Show("Bạn Có Muốn Xóa?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SqlHelper.ExecuteNonQuery(Connection.sqlcon, "PHONGBENH_Delete", txt_MaPB.Text);
                        MessageBox.Show("Đã xóa phòng bệnh", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDSPB();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không Thể Xóa, Vui Lòng Kiểm Tra Lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
                MessageBox.Show("Dữ Liệu Trống,Không Thể Xóa!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        //Refresh thông tin phòng bệnh
        private void btn_LoadPB_Click(object sender, EventArgs e)
        {
            LoadDSPB();
        }
        //-----------------------------------------/* Phân Công *\---------------------------------------------
        DataTable Tb_PHANCONG_Select;
        private void LoadDSPC()
        {
            Tb_PHANCONG_Select = SqlHelper.ExecuteDataset(Connection.sqlcon, "PHANCONG_Select").Tables[0];
            grd_PhanCong.DataSource = Tb_PHANCONG_Select;
        }
        //Tab Phân Công
        private void btn_PC_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            XtraTabPage tabPhanCong = new XtraTabPage();
            tabPhanCong.Text = "Phân Công";
            Tab_PhanCong.PageVisible = true;
            Tab_Main.SelectedTabPage = Tab_Main.TabPages[ViTriTabPage(tabPhanCong.Text)];
            LoadDSPC();
        }
        private void gridViewPhanCong_RowCellClick(object sender, DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs e)
        {
            
        }
        private void gridViewPhanCong_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            txt_NhomMau.Text = gridViewPhanCong.GetFocusedDataRow()["NhomMau"].ToString();
            txt_DiUngThuoc.Text = gridViewPhanCong.GetFocusedDataRow()["DiUngThuoc"].ToString();
            txt_TinhTrangBN.Text = gridViewPhanCong.GetFocusedDataRow()["TinhTrangBenhNhan"].ToString();
            txt_MaBacSyPC.Text = gridViewPhanCong.GetFocusedDataRow()["MaBacSy"].ToString();
            txt_MaBenhNhanPC.Text = gridViewPhanCong.GetFocusedDataRow()["MaSoBenhNhan"].ToString();
        }
        private void barButtonItem13_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        private void ribbon_Click(object sender, EventArgs e)
        {

        }
        //Thêm PC
        string TestbtnPC = "";
        private void btn_ThemPC_Click(object sender, EventArgs e)
        {
            btn_ThemPC.Enabled = false;
            btn_SuaPC.Enabled = false;
            btn_LuuPC.Enabled = true;
            btn_HuyPC.Enabled = true;
            btn_XoaPC.Enabled = false;
            txt_MaBacSyPC.ReadOnly = false;
            txt_MaBenhNhanPC.ReadOnly = false;
            txt_NhomMau.ReadOnly = false;
            txt_DiUngThuoc.ReadOnly = false;
            txt_TinhTrangBN.ReadOnly = false;
            txt_MaBacSyPC.Text = "";
            txt_MaBenhNhanPC.Text = "";
            txt_NhomMau.Text = "";
            txt_DiUngThuoc.Text = "";
            txt_TinhTrangBN.Text = "";
            grd_PhanCong.Enabled = false;
            TestbtnPC = "Them";
        }
        //Sửa phân công
        private void btn_SuaPC_Click(object sender, EventArgs e)
        {
            btn_ThemPC.Enabled = false;
            btn_SuaPC.Enabled = false;
            btn_LuuPC.Enabled = true;
            btn_HuyPC.Enabled = true;
            btn_XoaPC.Enabled = false;
            txt_MaBacSyPC.ReadOnly = false;
            txt_MaBenhNhanPC.ReadOnly = false;
            txt_NhomMau.ReadOnly = false;
            txt_DiUngThuoc.ReadOnly = false;
            txt_TinhTrangBN.ReadOnly = false;
            TestbtnPC = "Sua";
        }
        //hủy thêm/sửa phân công
        private void btn_HuyPC_Click(object sender, EventArgs e)
        {
            btn_ThemPC.Enabled = true;
            btn_SuaPC.Enabled = true;
            btn_LuuPC.Enabled = false;
            btn_HuyPC.Enabled = false;
            btn_XoaPC.Enabled = true;
            txt_MaBacSyPC.ReadOnly = true;
            txt_MaBenhNhanPC.ReadOnly = true;
            txt_NhomMau.ReadOnly = true;
            txt_DiUngThuoc.ReadOnly = true;
            txt_TinhTrangBN.ReadOnly = true;
            grd_PhanCong.Enabled = true;
        }

        private void btn_LuuPC_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (txt_MaBacSyPC.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã bác sỹ!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaBacSyPC.Focus();
                }
                else if (txt_MaBenhNhanPC.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập mã bệnh nhân!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaBenhNhanPC.Focus();
                }
                else if (txt_NhomMau.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Nhóm Máu!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_NhomMau.Focus();
                }
                else if (txt_DiUngThuoc.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Dị ứng thuốc!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_DiUngThuoc.Focus();
                }
                else if (txt_TinhTrangBN.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Tình trạng bệnh nhân!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_TinhTrangBN.Focus();
                }
                else if (TestbtnPC == "Them")
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "PHANCONG_Insert",txt_MaBacSyPC.Text,txt_MaBenhNhanPC.Text,txt_NhomMau.Text,txt_DiUngThuoc.Text,txt_TinhTrangBN.Text);
                    MessageBox.Show("Phân công điều trị thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSPC();
                    btn_ThemPC.Enabled = true;
                    btn_SuaPC.Enabled = true;
                    btn_LuuPC.Enabled = false;
                    btn_HuyPC.Enabled = false;
                    btn_XoaPC.Enabled = true;
                    txt_MaBacSyPC.ReadOnly = true;
                    txt_MaBenhNhanPC.ReadOnly = true;
                    txt_NhomMau.ReadOnly = true;
                    txt_DiUngThuoc.ReadOnly = true;
                    txt_TinhTrangBN.ReadOnly = true;
                    grd_PhanCong.Enabled = true;
                    TestbtnPC = "";
                }
                else if (TestbtnPC == "Sua")
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "PHANCONG_Update", txt_MaBacSyPC.Text, txt_MaBenhNhanPC.Text, txt_NhomMau.Text, txt_DiUngThuoc.Text, txt_TinhTrangBN.Text);
                    MessageBox.Show("Sửa Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSPC();
                    btn_ThemPC.Enabled = true;
                    btn_SuaPC.Enabled = true;
                    btn_LuuPC.Enabled = false;
                    btn_HuyPC.Enabled = false;
                    btn_XoaPC.Enabled = true;
                    txt_MaBacSyPC.ReadOnly = true;
                    txt_MaBenhNhanPC.ReadOnly = true;
                    txt_NhomMau.ReadOnly = true;
                    txt_DiUngThuoc.ReadOnly = true;
                    txt_TinhTrangBN.ReadOnly = true;
                    grd_PhanCong.Enabled = true;
                    TestbtnPC = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui Lòng Nhập Đúng Kiểu Dữ Liệu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Xóa phân công
        private void btn_XoaPC_Click(object sender, EventArgs e)
        {
            if (Tb_PHANCONG_Select.Rows.Count > 0)
            {
                try
                {
                    if (MessageBox.Show("Xóa phân công điều trị?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SqlHelper.ExecuteNonQuery(Connection.sqlcon, "PHANCONG_Delete", txt_MaBacSyPC.Text,txt_MaBenhNhanPC.Text);
                        MessageBox.Show("Xóa Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDSPC();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không Thể Xóa, Vui Lòng Kiểm Tra Lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
                MessageBox.Show("Dữ Liệu Trống,Không Thể Xóa!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        //Refresh thông tin phân công
        private void btn_LoadPC_Click(object sender, EventArgs e)
        {
            LoadDSPC();
        }
        //---------------------------------/* Sắp xếp bệnh nhân \*--------------------------------------
        DataTable Tb_SXBENHNHAN_Select;
        private void LoadSXBN()
        {
            Tb_SXBENHNHAN_Select = SqlHelper.ExecuteDataset(Connection.sqlcon, "SXBENHNHAN_Select").Tables[0];
            grd_SXBN.DataSource = Tb_SXBENHNHAN_Select;
        }
        //Tab sắp xếp bệnh nhân
        private void btn_SapXepBN_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            XtraTabPage tabSXBenhNhan= new XtraTabPage();
            tabSXBenhNhan.Text = "Sắp Xếp Bệnh Nhân";
            Tab_SapXepBenhNhan.PageVisible = true;
            Tab_Main.SelectedTabPage = Tab_Main.TabPages[ViTriTabPage(tabSXBenhNhan.Text)];
            LoadSXBN();
        }

        private void gridViewSXBN_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            txt_MSBNSapXep.Text = gridViewSXBN.GetFocusedDataRow()["MaSoBenhNhan"].ToString();
            txt_MGBSapXep.Text = gridViewSXBN.GetFocusedDataRow()["MaGiuongBenh"].ToString();
            date_TimeNV.Text = gridViewSXBN.GetFocusedDataRow()["ThoiDiemNamVien"].ToString();
            date_TimeXV.Text = gridViewSXBN.GetFocusedDataRow()["ThoiDiemXuatVien"].ToString();
        }
        //sắp xếp giường cho bệnh nhân
        string TestbtnSXBN = "";
        private void btn_ThemSX_Click(object sender, EventArgs e)
        {
            btn_ThemSX.Enabled = false;
            btn_SuaSX.Enabled = false;
            btn_LuuSX.Enabled = true;
            btn_HuySX.Enabled = true;
            btn_XoaSX.Enabled = false;
            txt_MSBNSapXep.ReadOnly = false;
            txt_MGBSapXep.ReadOnly = false;
            date_TimeNV.ReadOnly = false;
            date_TimeXV.ReadOnly = false;
            txt_MSBNSapXep.Text = "";
            txt_MGBSapXep.Text = "";
            date_TimeNV.Text = "";
            date_TimeXV.Text = "";
            grd_SXBN.Enabled = false;
            TestbtnSXBN = "Them";
        }
        //Sửa thời điểm nằm/xuất viện
        private void btn_SuaSX_Click(object sender, EventArgs e)
        {
            btn_ThemSX.Enabled = false;
            btn_SuaSX.Enabled = false;
            btn_LuuSX.Enabled = true;
            btn_HuySX.Enabled = true;
            btn_XoaSX.Enabled = false;
            txt_MSBNSapXep.ReadOnly = false;
            txt_MGBSapXep.ReadOnly = false;
            date_TimeNV.ReadOnly = false;
            date_TimeXV.ReadOnly = false;
            TestbtnSXBN = "Sua";
        }
        //Hủy Thêm/Sửa
        private void btn_HuySX_Click(object sender, EventArgs e)
        {
            btn_ThemSX.Enabled = true;
            btn_SuaSX.Enabled = true;
            btn_LuuSX.Enabled = false;
            btn_HuySX.Enabled = false;
            btn_XoaSX.Enabled = true;
            txt_MSBNSapXep.ReadOnly = true;
            txt_MGBSapXep.ReadOnly = true;
            date_TimeNV.ReadOnly = true;
            date_TimeXV.ReadOnly = true;
            grd_SXBN.Enabled = true;
        }
        //Lưu 
        private void btn_LuuSX_Click(object sender, EventArgs e)
        {
            
            try
            {
                
                if (txt_MSBNSapXep.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã số bệnh nhân!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MSBNSapXep.Focus();
                }
                else if (txt_MGBSapXep.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập mã giường !", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MGBSapXep.Focus();
                }
                else if (date_TimeNV.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Thời gian bắt đầu nằm viện!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    date_TimeNV.Focus();
                }
                else if (date_TimeXV.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Thời gian xuất viện!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    date_TimeXV.Focus();
                }
                else if (TestbtnSXBN == "Them" )
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "SXBENHNHAN_Insert", txt_MSBNSapXep.Text,txt_MGBSapXep.Text,date_TimeNV.Text,date_TimeXV.Text);
                    MessageBox.Show("Đặt giường cho bệnh nhân thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadSXBN();
                    btn_ThemSX.Enabled = true;
                    btn_SuaSX.Enabled = true;
                    btn_LuuSX.Enabled = false;
                    btn_HuySX.Enabled = false;
                    btn_XoaSX.Enabled = true;
                    txt_MSBNSapXep.ReadOnly = true;
                    txt_MGBSapXep.ReadOnly = true;
                    date_TimeNV.ReadOnly = true;
                    date_TimeXV.ReadOnly = true;
                    grd_SXBN.Enabled = true;
                    TestbtnSXBN = "";
                }
                else if (TestbtnSXBN == "Sua")
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "SXBENHNHAN_Update", txt_MSBNSapXep.Text, txt_MGBSapXep.Text, date_TimeNV.Text, date_TimeXV.Text);
                    MessageBox.Show("Sửa Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadSXBN();
                    btn_ThemSX.Enabled = true;
                    btn_SuaSX.Enabled = true;
                    btn_LuuSX.Enabled = false;
                    btn_HuySX.Enabled = false;
                    btn_XoaSX.Enabled = true;
                    txt_MSBNSapXep.ReadOnly = true;
                    txt_MGBSapXep.ReadOnly = true;
                    date_TimeNV.ReadOnly = true;
                    date_TimeXV.ReadOnly = true;
                    grd_SXBN.Enabled = true;
                    TestbtnSXBN = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui Lòng Nhập Đúng Kiểu Dữ Liệu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Bệnh nhân trả giường
        private void btn_XoaSX_Click(object sender, EventArgs e)
        {
            if (Tb_SXBENHNHAN_Select.Rows.Count > 0)
            {
                try
                {
                    if (MessageBox.Show("Bệnh nhân muốn trả giường?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SqlHelper.ExecuteNonQuery(Connection.sqlcon, "SXBENHNHAN_Delete", txt_MSBNSapXep.Text,txt_MGBSapXep.Text);
                        MessageBox.Show("Trả giường thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadSXBN();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không Thể Xóa, Vui Lòng Kiểm Tra Lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
                MessageBox.Show("Dữ Liệu Trống,Không Thể Xóa!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        //Refresh sắp xếp bệnh nhân
        private void btn_LoadSX_Click(object sender, EventArgs e)
        {
            LoadSXBN();
        }
        //----------------------------/* Hóa Đơn \*----------------------------------
        DataTable Tb_HOADON_Select;
        private void LoadDSHD()
        {
            Tb_HOADON_Select = SqlHelper.ExecuteDataset(Connection.sqlcon, "HOADON_Select").Tables[0];
            grd_HoaDon.DataSource = Tb_HOADON_Select;
        }

        private void gridViewHoaDon_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            txt_MaHoaDon.Text = gridViewHoaDon.GetFocusedDataRow()["MaHoaDon"].ToString();
            txt_DonGia.Text = gridViewHoaDon.GetFocusedDataRow()["DonGia"].ToString();
            date_NgayLapHD.Text = gridViewHoaDon.GetFocusedDataRow()["NgayLap"].ToString();
            cbb_MaGiuong.SelectedValue = gridViewHoaDon.GetFocusedDataRow()["MaGiuongBenh"].ToString();
        }
        //Tab Hóa Đơn
        private void btn_HoaDon_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            XtraTabPage tabHoaDon = new XtraTabPage();
            tabHoaDon.Text = "Hóa Đơn";
            Tab_HoaDon.PageVisible = true;
            Tab_Main.SelectedTabPage = Tab_Main.TabPages[ViTriTabPage(tabHoaDon.Text)];
            LoadDSHD();
            cbb_MaGiuong.DataSource = SqlHelper.ExecuteDataset(Connection.sqlcon, "GIUONGBENH_Select").Tables[0];
            cbb_MaGiuong.DisplayMember = "LoaiGiuong";
            cbb_MaGiuong.ValueMember = "MaGiuongBenh";
        }
        string TestbtnHD = "";
        //Thêm hóa đơn
        private void btn_ThemHD_Click(object sender, EventArgs e)
        {
            btn_ThemHD.Enabled = false;
            btn_SuaHD.Enabled = false;
            btn_LuuHD.Enabled = true;
            btn_HuyHD.Enabled = true;
            btn_XoaHD.Enabled = false;
            txt_MaHoaDon.Text = "";
            txt_DonGia.Text = "";
            date_NgayLapHD.Text = "";
            cbb_MaGiuong.Text = "";
            grd_HoaDon.Enabled = false;
            txt_MaHoaDon.ReadOnly = false;
            txt_DonGia.ReadOnly = false;
            date_NgayLapHD.ReadOnly = false;
            cbb_MaGiuong.Enabled = true;
            TestbtnHD = "Them";
        }
        //Sửa hóa đơn
        private void btn_SuaHD_Click(object sender, EventArgs e)
        {
            btn_ThemHD.Enabled = false;
            btn_SuaHD.Enabled = false;
            btn_LuuHD.Enabled = true;
            btn_HuyHD.Enabled = true;
            btn_XoaHD.Enabled = false;
            txt_MaHoaDon.ReadOnly = false;
            txt_DonGia.ReadOnly = false;
            date_NgayLapHD.ReadOnly = false;
            cbb_MaGiuong.Enabled = true;
            TestbtnHD = "Sua";
        }
        //Hủy thêm/sửa hóa đơn
        private void btn_HuyHD_Click(object sender, EventArgs e)
        {
            btn_ThemHD.Enabled = true;
            btn_SuaHD.Enabled = true;
            btn_LuuHD.Enabled = false;
            btn_HuyHD.Enabled = false;
            btn_XoaHD.Enabled = true;
            txt_MaHoaDon.ReadOnly = true;
            txt_DonGia.ReadOnly = true;
            date_NgayLapHD.ReadOnly = true;
            cbb_MaGiuong.Enabled = false;
            grd_HoaDon.Enabled = true;
        }
        //Lưu hóa đơn
        private void btn_LuuHD_Click(object sender, EventArgs e)
        {
            bool key = true;
            try
            {
                for (int i = 0; i < Tb_HOADON_Select.Rows.Count; i++)
                {
                    if (txt_MaPB.Text == Tb_HOADON_Select.Rows[i][0].ToString())
                        key = false;
                }
                if (txt_MaHoaDon.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Mã hóa đơn!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaHoaDon.Focus();
                }
                else if (TestbtnHD == "Them" && key == false)
                {
                    MessageBox.Show("Mã Hóa Đơn Đã Có, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MaHoaDon.Focus();
                }
                else if (txt_DonGia.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Đơn Giá!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_DonGia.Focus();
                }
                else if (date_NgayLapHD.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Nhập Ngày lập hóa đơn!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    date_NgayLapHD.Focus();
                }
                else if (cbb_MaGiuong.Text == "")
                {
                    MessageBox.Show("Bạn Chưa Chọn Loại Giường Bệnh!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cbb_MaGiuong.Focus();
                }
                else if (IsNumber(txt_DonGia.Text) == false)
                {
                    MessageBox.Show("Đơn giá nhập vào không hợp lệ, Vui Lòng Kiểm Tra Lại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_DonGia.Focus();
                }
                else if (TestbtnHD == "Them" && key == true)
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "HOADON_Insert",txt_MaHoaDon.Text,cbb_MaGiuong.SelectedValue.ToString(),txt_DonGia.Text,date_NgayLapHD.Text);
                    MessageBox.Show("Thêm hóa đơn cho bệnh nhân thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSHD();
                    btn_ThemHD.Enabled = true;
                    btn_SuaHD.Enabled = true;
                    btn_LuuHD.Enabled = false;
                    btn_HuyHD.Enabled = false;
                    btn_XoaHD.Enabled = true;
                    txt_MaHoaDon.ReadOnly = true;
                    txt_DonGia.ReadOnly = true;
                    date_NgayLapHD.ReadOnly = true;
                    cbb_MaGiuong.Enabled = false;
                    grd_HoaDon.Enabled = true;
                    TestbtnHD = "";
                }
                else if (TestbtnHD == "Sua")
                {
                    SqlHelper.ExecuteNonQuery(Connection.sqlcon, "HOADON_Update", txt_MaHoaDon.Text, cbb_MaGiuong.SelectedValue.ToString(), txt_DonGia.Text, date_NgayLapHD.Text);
                    MessageBox.Show("Sửa hóa đơn thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDSHD();
                    btn_ThemHD.Enabled = true;
                    btn_SuaHD.Enabled = true;
                    btn_LuuHD.Enabled = false;
                    btn_HuyHD.Enabled = false;
                    btn_XoaHD.Enabled = true;
                    txt_MaHoaDon.ReadOnly = true;
                    txt_DonGia.ReadOnly = true;
                    date_NgayLapHD.ReadOnly = true;
                    cbb_MaGiuong.Enabled = false;
                    grd_HoaDon.Enabled = true;
                    TestbtnHD = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Vui Lòng Nhập Đúng Kiểu Dữ Liệu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //Thanh toán hóa đơn
        private void btn_XoaHD_Click(object sender, EventArgs e)
        {
            if (Tb_HOADON_Select.Rows.Count > 0)
            {
                try
                {
                    if (MessageBox.Show("Bệnh nhân thanh toán ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SqlHelper.ExecuteNonQuery(Connection.sqlcon, "HOADON_Delete", txt_MaHoaDon.Text);
                        MessageBox.Show("Thanh toán thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDSHD();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không Thể Xóa, Vui Lòng Kiểm Tra Lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
                MessageBox.Show("Dữ Liệu Trống,Không Thể Xóa!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        //Refresh lại hóa đơn
        private void btn_LoadHD_Click(object sender, EventArgs e)
        {
            LoadDSHD();
        }
    }
}
