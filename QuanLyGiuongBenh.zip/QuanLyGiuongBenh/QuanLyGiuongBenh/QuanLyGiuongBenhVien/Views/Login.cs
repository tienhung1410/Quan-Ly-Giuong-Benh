﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using QuanLyGiuongBenhVien.Models;

namespace QuanLyGiuongBenhVien.Views
{
    public partial class Login : DevExpress.XtraEditors.XtraForm
    {
        public Login()
        {
            InitializeComponent();
        }
        Connection cls_ketnoi = new Connection();
        private void Login_Load(object sender, EventArgs e)
        {
            txtPass.Properties.PasswordChar = '*';
        }
        public static string user;
        public static bool nv;

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //DataTable tb = SqlHelper.ExecuteDataset(Connection.sqlcon, "NHANVIEN_Select_TK", txtName.Text, txtPass.Text).Tables[0];
            DataTable tbs = SqlHelper.ExecuteDataset(Connection.sqlcon, "ADMIN_Select_TK", txtName.Text, txtPass.Text).Tables[0];

            if (txtPass.Text == "" && txtName.Text == "")
            {
                MessageBox.Show("Tài khoản Và Mật Khẩu Không Được Để Trống!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
            }
            else if (txtName.Text == "")
            {
                MessageBox.Show("Tài khỏan Không Được Để Trống!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
            }
            else if (txtPass.Text == "")
            {
                MessageBox.Show("Mật Khẩu Không Được Để Trống!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPass.Focus();
            }
            else if (tbs.Rows.Count > 0)
            {
                user = txtName.Text;
                MessageBox.Show("Đăng Nhập Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
            }
            /*else if (tb.Rows.Count > 0)
            {
                user = txtName.Text;
                MessageBox.Show("Đăng Nhập Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                nv = true;
                this.Hide();
            }*/
            else
            {
                MessageBox.Show("Đăng Nhập Thất Bại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
            }
        }
    }
}