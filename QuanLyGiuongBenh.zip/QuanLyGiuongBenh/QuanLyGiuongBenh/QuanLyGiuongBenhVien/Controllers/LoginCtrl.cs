﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyGiuongBenhVien.Controllers
{
    class LoginCtrl
    {
        public static string CheckDangNhap(string _user, string _pass)
        {
            try
            {
                Models.LoginMod Login = new Models.LoginMod(_user, _pass);
                return Login.ADMIN_Select_TK();
            }
            catch { return ""; }
        }
    }
}
